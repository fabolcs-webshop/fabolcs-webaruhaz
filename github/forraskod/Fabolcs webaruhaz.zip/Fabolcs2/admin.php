<?php
session_start(); // Session indítása a felhasználói állapot követéséhez
require_once 'adatbazis.php'; // Adatbázis kapcsolat betöltése

// Bejelentkezés és admin jogosultság ellenőrzése
if (!isset($_SESSION['felhasznalo_id'])) {
    header("Location: bejelentkezes.php"); // Ha nincs bejelentkezve, átirányítás a bejelentkezés oldalra
    exit();
}

$felhasznalo_id = $_SESSION['felhasznalo_id']; // Bejelentkezett felhasználó ID-jának lekérése
$admin_stmt = $adatbazis->prepare("SELECT admin FROM felhasznalok WHERE id = ?"); // Lekérdezés az admin jogosultságra
$admin_stmt->bind_param("i", $felhasznalo_id); // Paraméter kötése
$admin_stmt->execute(); // Lekérdezés végrehajtása
$admin_stmt->bind_result($admin); // Eredmény kötése változóhoz
$admin_stmt->fetch(); // Eredmény beolvasása
$admin_stmt->close(); // Lekérdezés lezárása

if (!$admin) {
    echo "Nincs jogosultságod az oldal eléréséhez."; // Ha nem admin, figyelmeztetés megjelenítése
    exit();
}

// Rendelés státusz frissítés feldolgozása, ha POST kérés érkezett
if (isset($_POST['statusz_mentes'])) {
    $uj_statusz = $_POST['statusz']; // Új státusz érték lekérése
    $rendeles_id = (int)$_POST['rendeles_id']; // Rendelés azonosító lekérése

    // Frissítő lekérdezés előkészítése az új státusz beállítására
    $stmt = $adatbazis->prepare("UPDATE uj_rendelesek SET statusz = ? WHERE id = ?");
    $stmt->bind_param("si", $uj_statusz, $rendeles_id); // Paraméterek kötése
    $stmt->execute(); // Lekérdezés futtatása
    $stmt->close(); // Lekérdezés lezárása

    // Oldal újratöltése státusz frissítés után visszajelzéssel
    header("Location: admin.php?statusz_updated=1");
    exit();
}

// Teljes részletes rendelés lista lekérdezése, több kapcsolódó táblával együtt
$sql = "
    SELECT 
        r.id, r.rendeles_azonosito, r.datum, r.statusz, r.megjegyzes,   -- rendelés adatai
        f.email, f.telefon,                                            -- vásárló email és telefonszám
        c.cim,                                                        -- szállítási cím
        sp.nev AS szallitas_nev, sp.ar AS szallitas_ar               -- szállítási partner neve és ára
    FROM uj_rendelesek r
    JOIN felhasznalok f ON r.felhasznalo_id = f.id                  -- vásárlók csatlakoztatása
    LEFT JOIN szallitasi_cimek c ON r.szallitasi_cimek_id = c.id    -- szállítási cím bal oldali csatlakoztatása (opcionális)
    LEFT JOIN szallitasi_partnerek sp ON r.szallitasi_partner_id = sp.id  -- szállítási partner bal oldali csatlakoztatása (opcionális)
    ORDER BY r.datum DESC                                            -- legfrissebb rendelés előrébb
";
$rend_stmt = $adatbazis->prepare($sql); // Lekérdezés előkészítése
$rend_stmt->execute();                  // Lekérdezés végrehajtása
$rendelesek = $rend_stmt->get_result(); // Eredmény lekérése táblázatként
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Rendelések kezelése</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css"> <!-- Külső CSS fájl betöltése -->
    <style>
        /* Egyedi betűtípus betöltése */
        @font-face {
    font-family: 'Distant Stroke';
    src: url('fonts/Distant_Stroke.otf') format('opentype');
    font-weight: normal;
    font-style: normal;
                    }

        /* Alap body stílusok */
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            display: flex; /* Flexbox elrendezés */
            flex-direction: column; /* Vertikális irány */
            align-items: center; /* Középre igazítás vízszintesen */
            background-color: #4b2e1e; /* Sötétbarna háttér */
            position: relative;
            min-height: 100vh; /* Legalább teljes képernyő magasság */
        }
        /* Háttér textúra: faerezet */
        body::after {
            content: "";
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            background: url('kepek/erezet2.jpg') repeat; /* ismétlődő kép */
            z-index: -1; /* háttérbe küldve */
        }

        /* Nagy logó doboz a tetején */
        .logo-box {
            background: #5c3a2e; /* sötétbarna háttér */
            border-radius: 12px; /* lekerekített sarkok */
            padding: 10px 30px;
            margin: 30px auto 10px; /* középre igazítás, margók fent és lent */
            max-width: 720px; /* max szélesség */
            width: 95%; /* rugalmas szélesség */
            text-align: center;
            font-family: 'Distant Stroke', sans-serif; /* egyedi betűtípus */
            font-size: 80px;
            color: #ffffff; /* fehér szöveg */
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2); /* árnyék */
        }

        /* Modal doboz stílusa */
        .modal-box {
            background: #f5f5dc; /* világos bézs háttér */
            border-radius: 12px;
            padding: 30px;
            max-width: 900px; /* szélesebb, mint a logó */
            width: 95%;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
            margin-bottom: 30px; /* alsó margó */
        }

        /* Modal fejléc */
        .modal-header {
            margin-bottom: 20px;
            text-align: center; /* középre igazítás */
        }
        /* Modal címsor stílusa */
.modal-title {
    font-size: 28px;         /* Nagyobb betűméret a címnek */
    font-weight: bold;       /* Félkövér betű */
    color: #333;             /* Sötétszürke szín */
}

/* Egy-egy rendelési sor megjelenítése flexbox-szal */
.rendeles-sor {
    display: flex;           /* Flexbox elrendezés */
    flex-wrap: wrap;         /* Sortörés mobilon, ha nem fér el */
    justify-content: space-between; /* Elemközi tér kitöltése */
    gap: 20px;               /* Elemközi hézag */
    border-bottom: 1px solid #ddd; /* Alsó határvonal */
    padding: 10px 0 20px;    /* Felső és alsó belső margó */
}

/* Címkék stílusa a rendelési sorban */
.label {
    font-weight: bold;       /* Félkövér szöveg */
    margin-bottom: 4px;      /* Alatta kis tér */
    font-size: 14px;         /* Kis betűméret */
}

/* Cellák elrendezése a rendelési sorban */
.cell {
    display: flex;
    flex-direction: column;  /* Függőleges elemek */
    gap: 4px;                /* Kis hézag a cella elemei között */
    flex: 1 1 200px;         /* Rugalmas méret, minimum 200px */
}

/* Műveleti cella (pl. gombok) jobbra zárva */
.muvcell {
    display: flex;
    flex-direction: column;
    justify-content: flex-end; /* Alulra igazítás függőlegesen */
    align-items: flex-end;     /* Jobbra igazítás vízszintesen */
    flex: 1 1 100%;            /* Teljes szélesség, rugalmas */
}

/* Legördülő menü (select) stílusa */
select {
    padding: 8px;              /* Belső margó */
    border-radius: 5px;        /* Lekerekített sarkok */
    border: 1px solid #ccc;    /* Finom szegély */
}

/* Gombok alapstílusa */
button {
    padding: 8px 16px;         /* Belső margó */
    border-radius: 5px;        /* Lekerekített sarkok */
    background-color: #5c3a2e; /* Sötétbarna háttér */
    color: white;              /* Fehér szöveg */
    font-weight: bold;         /* Félkövér betű */
    border: none;              /* Nincs keret */
    cursor: pointer;           /* Kéz kurzor hoverkor */
}

/* Gombokat tartalmazó konténer */
.gombok {
    display: flex;
    justify-content: center;   /* Középre igazítás vízszintesen */
    gap: 10px;                 /* Gombok közti hézag */
    margin-top: 20px;          /* Felül margó */
    flex-wrap: wrap;           /* Több sorba törhető mobilon */
}

/* Gombok link stílusa */
.gombok a {
    padding: 10px 20px;
    background-color: #5c3a2e; /* Sötétbarna háttér */
    color: white;              /* Fehér szöveg */
    text-decoration: none;     /* Aláhúzás eltávolítása */
    border-radius: 5px;        /* Lekerekített sarkok */
    font-weight: bold;         /* Félkövér betű */
}
    </style>
<!DOCTYPE html>
<html lang="hu">
<head>
<meta charset="UTF-8">
<title>Rendelések kezelése</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
/* (CSS stílusok itt vannak – a korábban már kommentált CSS-hez hasonlóak) */
</style>
</head>
<body>
<div class="logo-box">Fabolcs</div>
<div class="modal-box">

    <!-- Modal fejléc címmel -->
    <div class="modal-header">
        <div class="modal-title">Rendelések kezelése</div>
    </div>

    <!-- PHP ciklus: minden rendeléshez létrehoz egy űrlapot -->
    <?php while ($rend = $rendelesek->fetch_assoc()): ?>
        <?php
        // A rendeléshez tartozó termékek lekérdezése külön lekérdezéssel
        $termekek = [];
        $stmt2 = $adatbazis->prepare("
            SELECT t.nev, rt.mennyiseg
            FROM rendeles_tetelek rt
            JOIN termekek t ON rt.termek_id = t.id
            WHERE rt.rendeles_id = ?
        ");
        $stmt2->bind_param("i", $rend['id']);
        $stmt2->execute();
        $res2 = $stmt2->get_result();

        // A termékeket beletesszük a $termekek tömbbe
        while ($row2 = $res2->fetch_assoc()) {
            $termekek[] = $row2;
        }
        $stmt2->close();
        ?>

        <!-- Rendeléshez tartozó űrlap a státusz módosításához -->
        <form method="post" class="rendeles-sor">
            <!-- Rejtett mezőben a rendelés ID-ja -->
            <input type="hidden" name="rendeles_id" value="<?= $rend['id'] ?>">

            <!-- Email cím megjelenítése -->
            <div class="cell">
                <label class="label">Email</label>
                <strong><?= htmlspecialchars($rend['email']) ?></strong>
            </div>

            <!-- Telefonszám megjelenítése, ha van -->
            <?php if (!empty($rend['telefon'])): ?>
                <div class="cell">
                    <label class="label">Telefonszám</label>
                    <div><?= htmlspecialchars($rend['telefon']) ?></div>
                </div>
            <?php endif; ?>

            <!-- Rendelés azonosító megjelenítése -->
            <div class="cell">
                <label class="label">Azonosító</label>
                <div><?= htmlspecialchars($rend['rendeles_azonosito']) ?></div>
            </div>

            <!-- Rendelés dátuma -->
            <div class="cell">
                <label class="label">Dátum</label>
                <div><?= htmlspecialchars($rend['datum']) ?></div>
            </div>

            <!-- Szállítási cím megjelenítése, ha van -->
            <?php if (!empty($rend['cim'])): ?>
                <div class="cell">
                    <label class="label">Szállítási cím</label>
                    <div><?= nl2br(htmlspecialchars($rend['cim'])) ?></div>
                </div>
            <?php endif; ?>

            <!-- Szállítási partner neve és ára -->
            <?php if (!empty($rend['szallitas_nev'])): ?>
                <div class="cell">
                    <label class="label">Szállítási partner</label>
                    <div><?= htmlspecialchars($rend['szallitas_nev']) ?> (<?= $rend['szallitas_ar'] ?> Ft)</div>
                </div>
            <?php endif; ?>

            <!-- Rendeléshez írt megjegyzés megjelenítése, ha van -->
            <?php if (!empty($rend['megjegyzes'])): ?>
                <div class="cell">
                    <label class="label">Megjegyzés</label>
                    <div><?= nl2br(htmlspecialchars($rend['megjegyzes'])) ?></div>
                </div>
            <?php endif; ?>

            <!-- Rendelt termékek listája -->
            <?php if (!empty($termekek)): ?>
                <div class="cell">
                    <label class="label">Termékek</label>
                    <ul>
                        <?php foreach ($termekek as $t): ?>
                            <li><?= htmlspecialchars($t['nev']) ?> × <?= $t['mennyiseg'] ?> db</li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <!-- Státusz választó mező -->
            <div class="cell">
                <label class="label">Státusz</label>
                <select name="statusz">
                    <option value="" <?= empty($rend['statusz']) ? 'selected' : '' ?>>Nincs fizetve</option>
                    <option value="fizetve" <?= $rend['statusz'] === 'fizetve' ? 'selected' : '' ?>>Fizetve</option>
                    <option value="gyartas" <?= $rend['statusz'] === 'gyartas' ? 'selected' : '' ?>>Gyártás alatt</option>
                    <option value="kiszallitas" <?= $rend['statusz'] === 'kiszallitas' ? 'selected' : '' ?>>Kiszállítás alatt</option>
                    <option value="kezbesitve" <?= $rend['statusz'] === 'kezbesitve' ? 'selected' : '' ?>>Kézbesítve</option>
                </select>
            </div>

            <!-- Mentés gomb a státusz módosításához -->
            <div class="muvcell">
                <label class="label">Művelet</label>
                <button type="submit" name="statusz_mentes">Mentés</button>
            </div>
        </form>
    <?php endwhile; ?>

    <!-- Navigációs gombok az admin felülethez -->
    <div class="gombok">
        <a href="index.php">Főoldal</a>
        <a href="admin_uj_termek.php">Új termék</a>
        <a href="admin_termekek.php">Termékek</a>
    </div>
</div>
</body>
</html>






