<?php
// --- SESSION indítása, hogy a felhasználói adatokhoz hozzáférjünk
session_start();

// --- Adatbáziskapcsolat behúzása
require_once 'adatbazis.php';

// --- Ellenőrzés: be van-e jelentkezve és van-e véglegesítés adat a session-ben
if (!isset($_SESSION['felhasznalo_id']) || empty($_SESSION['veglegesites_adatok'])) {
    // Ha nincs, visszadobjuk a főoldalra
    header("Location: index.php");
    exit();
}

// --- Felhasználó ID a sessionből
$felhasznalo_id = $_SESSION['felhasznalo_id'];
// --- A session-ben tárolt véglegesítési adatok
$adatok = $_SESSION['veglegesites_adatok'];
$megjegyzes = $adatok['megjegyzes'] ?? null;
$cim_id = $adatok['szallitasi_cimek_id'];
$partner_id = $adatok['partner_id'];
$termekek = $adatok['termekek'];
$datum = date('Y-m-d H:i:s');  // Jelenlegi időbélyeg

// --- Egyedi rendelési azonosító generálása
function generalRendelesAzonosito() {
    $datum = date('Ymd');
    $random = strtoupper(substr(md5(uniqid(rand(), true)), 0, 4));
    return "RND-$datum-$random";
}

$rendeles_azonosito = generalRendelesAzonosito();

// === 1. RENDELÉS FEJ ADATAINAK MENTÉSE az uj_rendelesek táblába ===
$statusz = 'uj';  // Kezdeti státusz
$stmt = $adatbazis->prepare(
    "INSERT INTO uj_rendelesek 
     (rendeles_azonosito, felhasznalo_id, szallitasi_cimek_id, szallitasi_partner_id, datum, statusz, megjegyzes) 
     VALUES (?, ?, ?, ?, ?, ?, ?)"
);
$stmt->bind_param("siissss", $rendeles_azonosito, $felhasznalo_id, $cim_id, $partner_id, $datum, $statusz, $megjegyzes);
$stmt->execute();
$rendeles_id = $adatbazis->insert_id;  // Az új rendelés ID-je
$stmt->close();

// === 2. RENDELÉS TÉTELEINEK MENTÉSE a rendeles_tetelek táblába ===
$stmt = $adatbazis->prepare(
    "INSERT INTO rendeles_tetelek (rendeles_id, termek_id, mennyiseg) VALUES (?, ?, ?)"
);

foreach ($termekek as $termek) {
    $termek_id = $termek['id'];
    $mennyiseg = $termek['mennyiseg'];
    $stmt->bind_param("iii", $rendeles_id, $termek_id, $mennyiseg);
    $stmt->execute();
}
$stmt->close();

// === 3. RENDELÉS VÉGLEGESÍTÉSE A rendeles_veglegesites táblába ===
$stmt = $adatbazis->prepare(
    "INSERT INTO rendeles_veglegesites (felhasznalo_id, szallitasi_cimek_id, szallitasi_partner_id, rendeles_datum) 
     VALUES (?, ?, ?, ?)"
);
$stmt->bind_param("iiis", $felhasznalo_id, $cim_id, $partner_id, $datum);
$stmt->execute();
$stmt->close();

// === 4. KOSÁR ÜRÍTÉSE adatbázisból és sessionből ===
$adatbazis->query("DELETE FROM kosar_tetelek WHERE felhasznalo_id = $felhasznalo_id");
unset($_SESSION['kosar']);
unset($_SESSION['veglegesites_adatok']);
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Rendelés sikeres</title>
    <style>
        /* ======= ALAP TEST BEÁLLÍTÁSOK ======= */
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            display: flex;                       /* Flexbox a középre igazításhoz */
            justify-content: center;             /* Vízszintesen középre */
            align-items: center;                 /* Függőlegesen középre */
            min-height: 100vh;                   /* Teljes képernyő magasság kitöltése */
            background-color: #4b2e1e;           /* Háttér barna szín */
            position: relative;
        }

        /* ======= HÁTTÉRKÉP (FAEREZET) ======= */
        body::after {
            content: "";
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('kepek/erezet2.jpg') repeat;
            background-size: auto;
            z-index: -1;                         /* Tartalom mögött jelenik meg */
        }

        /* ======= MODÁL DOBOZ STÍLUS ======= */
        .modal-box {
            background: white;
            border-radius: 12px;                 /* Lekerekített sarkok */
            padding: 30px;                       /* Belső margó */
            max-width: 600px;                    /* Max szélesség */
            width: 90%;                          /* Reszponzív szélesség */
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2); /* Árnyék */
            text-align: center;                  /* Szöveg középre igazítva */
        }

        /* ======= MODÁL CÍM ======= */
        .modal-box h2 {
            color: #28a745;                      /* Zöld szín a siker jelzésére */
        }

        /* ======= MODÁL SZÖVEG ======= */
        .modal-box p {
            font-size: 16px;
            margin: 15px 0;
        }

        /* ======= LINK GOMB STÍLUS ======= */
        .modal-box a {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 25px;
            background-color: #28a745;           /* Zöld háttér */
            color: white;                        /* Fehér szöveg */
            font-weight: bold;
            text-decoration: none;
            border-radius: 6px;
        }

        /* ======= LINK GOMB HOVER ======= */
        .modal-box a:hover {
            background-color: #218838;           /* Sötétebb zöld hoverkor */
        }
    </style>
</head>
<body>
    <!-- ======= MODÁL TARTALOM ======= -->
    <div class="modal-box">
        <!-- Siker üzenet -->
        <h2>Rendelése sikeres!</h2>

        <!-- Egyedi rendelési azonosító kiírása -->
        <p><strong>Rendelési azonosító:</strong> <?= htmlspecialchars($rendeles_azonosito) ?></p>

        <!-- Információs üzenet a fizetésről -->
        <p>A fizetési információkról az alábbi gombra kattintva, illetve fiókja oldalán kap értesítést.</p>

        <!-- Link a vásárlói fiók oldalára -->
        <a href="vasarlo_fiok.php">Fizetési információ</a>
    </div>
</body>
</html>