<?php
// ---------------------------
// Hibakijelzés bekapcsolása
// Fejlesztési környezetben ajánlott a hibák láthatóvá tétele.
// ÉLES üzemnél ezt ki kell majd kapcsolni!
// ---------------------------
ini_set('display_errors', 1);
error_reporting(E_ALL);

// ---------------------------
// Session indítása
// Szükséges a felhasználói állapot megőrzéséhez (bejelentkezés, kosár)
// ---------------------------
session_start();
require_once 'adatbazis.php'; // Adatbáziskapcsolat betöltése

// ---------------------------
// Ellenőrzés: Bejelentkezett-e a felhasználó?
// Ha nincs bejelentkezve, átirányítjuk a bejelentkezés oldalra
// ---------------------------
if (!isset($_SESSION['felhasznalo_id'])) {
    header("Location: bejelentkezes.php");
    exit();
}

// ---------------------------
// Alap változók inicializálása
// ---------------------------
$felhasznalo_id = $_SESSION['felhasznalo_id'];
$felhasznalo_email = $_SESSION['felhasznalo_email'] ?? '';  // opcionálisan elmentett email
$bejelentkezett = true;                                     // megjelölés, hogy belépett
$rendeles_megjegyzes = $_SESSION['rendeles_megjegyzes'] ?? ''; // korábban megadott megjegyzés

// ---------------------------
// Ha az oldal POST-kérést kapott, űrlap feldolgozás indul
// ---------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Felhasználó által megadott adatok olvasása és trimelése
    $nev = trim($_POST['nev'] ?? '');
    $irszam = trim($_POST['irszam'] ?? '');
    $varos = trim($_POST['varos'] ?? '');
    $utca = trim($_POST['utca'] ?? '');
    $szallitas = $_POST['szallitas'] ?? ''; // partner azonosító

    // --- Validálási hibák gyűjtésére tömb ---
    $hibak = [];

    // --- Név ellenőrzése ---
    if (!preg_match('/^[a-zA-ZáéíóöőúüűÁÉÍÓÖŐÚÜŰ\s-]{3,}$/u', $nev)) {
        $hibak[] = "A név csak betűket, szóközt és kötőjelet tartalmazhat, minimum 3 karakterrel.";
    }

    // --- Irányítószám ellenőrzése ---
    if (!preg_match('/^\d{4,5}$/', $irszam)) {
        $hibak[] = "Az irányítószám 4 vagy 5 számjegy lehet.";
    }

    // --- Városnév ellenőrzése ---
    if (!preg_match('/^[a-zA-ZáéíóöőúüűÁÉÍÓÖŐÚÜŰ\s-]{2,}$/u', $varos)) {
        $hibak[] = "A városnév csak betűket, szóközt és kötőjelet tartalmazhat, minimum 2 karakterrel.";
    }

    // --- Utca, házszám ellenőrzése ---
    if (!preg_match('/^[a-zA-Z0-9áéíóöőúüűÁÉÍÓÖŐÚÜŰ\s,.-]{3,}$/u', $utca)) {
        $hibak[] = "Az utca, házszám csak betűket, számokat, szóközt, vesszőt, pontot és kötőjelet tartalmazhat, minimum 3 karakterrel.";
    }

    // --- Szállítási partner ellenőrzése ---
    if (!is_numeric($szallitas)) {
        $hibak[] = "Érvénytelen szállítási partner!";
    }

    // ---------------------------
    // Ha bármilyen hiba volt, alerttel visszadobunk
    // ---------------------------
    if (!empty($hibak)) {
        $uzenet = implode('\n', $hibak);
        echo "<script>alert('Hiba:\\n$uzenet'); window.location.href='szallitas_cim.php';</script>";
        exit();
    }

    // ---------------------------
// A cím szöveg összeállítása
// Pl.: "1234 Budapest, Fő utca 5."
// ---------------------------
$cim = "$irszam $varos, $utca";
$partner_id = (int)$szallitas; // Szállítási partner azonosító számként

// ---------------------------
// Szállítási partner adatainak lekérése adatbázisból
// Dinamikusan ellenőrizzük, létezik-e, és kiolvassuk a nevét meg árát
// ---------------------------
$stmt = $adatbazis->prepare("SELECT nev, ar FROM szallitasi_partnerek WHERE id = ?");
$stmt->bind_param("i", $partner_id);
$stmt->execute();
$stmt->bind_result($partner_nev, $szallitas_ar);

// Ha nem található a partner ID, visszadobunk hibával
if (!$stmt->fetch()) {
    $stmt->close();
    echo "<script>alert('Érvénytelen szállítási partner!'); window.location.href='szallitas_cim.php';</script>";
    exit();
}
$stmt->close();

// ---------------------------
// Szállítási cím mentése adatbázisba
// A felhasználó ID-jához hozzárendeljük az új cím szövegét
// ---------------------------
$stmt = $adatbazis->prepare("INSERT INTO szallitasi_cimek (felhasznalo_id, cim) VALUES (?, ?)");
$stmt->bind_param("is", $felhasznalo_id, $cim);
$stmt->execute();
$szallitasi_cimek_id = $adatbazis->insert_id; // Frissen beszúrt cím ID-je
$stmt->close();

// ---------------------------
// Kosár tartalom összegyűjtése
// Megtöltjük a termékek tömböt és számoljuk a végösszeget
// ---------------------------
$termekek = [];
$vegosszeg = 0;

if ($bejelentkezett) {
    // Ha belépett felhasználó – a kosár a DB-ben van
    $stmt = $adatbazis->prepare("
        SELECT t.id, t.nev, t.ar, k.mennyiseg 
        FROM kosar_tetelek k 
        INNER JOIN termekek t ON k.termek_id = t.id 
        WHERE k.felhasznalo_id = ?
    ");
    $stmt->bind_param("i", $felhasznalo_id);
    $stmt->execute();
    $eredmeny = $stmt->get_result();

    // Beolvassuk soronként
    while ($sor = $eredmeny->fetch_assoc()) {
        $sor['reszosszeg'] = $sor['ar'] * $sor['mennyiseg']; // Egy sor értéke
        $vegosszeg += $sor['reszosszeg']; // Hozzáadjuk a végösszeghez
        $termekek[] = $sor; // Elmentjük a listába
    }

    $stmt->close();
} 
elseif (!empty($_SESSION['kosar'])) {
    // Ha vendég kosár van session-ben
    $kosar = $_SESSION['kosar'];
    $ids = implode(",", array_map("intval", array_keys($kosar))); // termék ID-k CSV listája

    $sql = "SELECT * FROM termekek WHERE id IN ($ids)";
    $eredmeny = $adatbazis->query($sql);

    // Termékek beolvasása
    while ($sor = $eredmeny->fetch_assoc()) {
        $termek_id = $sor['id'];
        $mennyiseg = $kosar[$termek_id];
        $sor['mennyiseg'] = $mennyiseg;
        $sor['reszosszeg'] = $mennyiseg * $sor['ar'];
        $vegosszeg += $sor['reszosszeg'];
        $termekek[] = $sor;
    }
}

// ---------------------------
// Ellenőrzés: üres kosár esetén visszadobás
// ---------------------------
if (empty($termekek)) {
    echo "<script>alert('A kosarad üres!'); window.location.href='home.php';</script>";
    exit();
}

// ---------------------------
// Szállítási díj hozzáadása a végösszeghez
// ---------------------------
$vegosszeg += $szallitas_ar;

// ---------------------------
// Minden adat SESSION-be mentése
// Később a véglegesítés oldalon tudjuk felhasználni
// ---------------------------
$_SESSION['veglegesites_adatok'] = [
    'nev' => $nev,
    'cim' => $cim,
    'szallitasi_cimek_id' => $szallitasi_cimek_id,
    'partner_id' => $partner_id,
    'partner_nev' => $partner_nev,
    'partner_ar' => $szallitas_ar,
    'termekek' => $termekek,
    'vegosszeg' => $vegosszeg,
    'megjegyzes' => $rendeles_megjegyzes
];
} else {
    // Ha nem POST-al hívták, visszadobjuk a cím megadás oldalra
    header("Location: szallitas_cim.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Rendelés véglegesítése</title>

    <style>
        /* ----------- Saját betűtípus betöltése ----------- */
        @font-face {
    font-family: 'Distant Stroke';
    src: url('fonts/Distant_Stroke.otf') format('opentype');
    font-weight: normal;
    font-style: normal;
}

        /* ----------- Oldal teljes háttér és layout ----------- */
        body {
            background-color: #4b2e1e; /* Sötétbarna háttérszín */
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;       /* Minden középre igazítva */
            justify-content: center;
            min-height: 100vh;         /* Legalább képernyő magasság */
            position: relative;
        }

        /* ----------- Háttér mintázat (fa erezet) ----------- */
        body::after {
            content: "";
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('kepek/erezet2.jpg') repeat;
            background-size: auto;
            z-index: -1;               /* Tartalom mögött marad */
        }

        /* ----------- Felső logó doboz ----------- */
        .logo-box {
            background: #5c3a2e;       /* Barna háttér */
            color: white;
            font-family: 'Distant Stroke', sans-serif;
            font-size: 60px;           /* Nagy felirat */
            padding: 10px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            max-width: 700px;
            width: 95%;                /* Mobilbarát szélesség */
            text-align: center;
        }

        /* ----------- Modal doboz a rendelés részleteihez ----------- */
        .modal {
            background: #f5f5dc;       /* Világos bézs háttér */
            border-radius: 12px;
            padding: 30px;
            max-width: 700px;
            width: 95%;
            box-shadow: 0 0 20px rgba(0,0,0,0.3); /* Árnyék körben */
        }

        /* ----------- Fejléc címek középre ----------- */
        h2 {
            text-align: center;
        }

        /* ----------- Rendelés információ blokk ----------- */
        .rendeles-info {
            margin-top: 20px;
        }

        .rendeles-info p {
            font-size: 16px;
            margin: 8px 0;
        }

        /* ----------- Listák a rendelési részletekhez ----------- */
        .rendeles-info ul {
            padding-left: 20px;
        }
         /* ----------- GOMB KONTAINER A LÁBLÉCEN ----------- */
        .gomb-container {
            display: flex;
            justify-content: center;   /* Gombokat középre igazítja vízszintesen */
            gap: 15px;                 /* Hézag a gombok között */
            margin-top: 30px;          /* Felülről távolság */
        }

        /* ----------- MINDEN GOMB / LINK ALAP STÍLUS ----------- */
        .gomb-container a,
        .gomb-container button {
            text-decoration: none;
            padding: 12px 20px;
            border-radius: 5px;
            font-weight: bold;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }

        /* ----------- FŐ GOMB (RENDELÉS LEADÁSA) ZÖLD SZÍNBEN ----------- */
        .gomb-container button {
            background-color: #28a745; /* Élénk zöld szín */
            color: white;
        }

        /* ----------- VISSZA GOMB SÖTÉT BARNA SZÍN ----------- */
        .gomb-container .vissza {
            background-color: #5c3a2e; /* Barna szín */
            color: white;
        }
    </style>
</head>
<body>
<!-- ----------- OLDAL FEJLÉC LOGÓ ----------- -->
<div class="logo-box">Fabolcs</div>

<!-- ----------- MODAL DOBOZ A RENDELÉS ÖSSZEFOGLALÓHOZ ----------- -->
<div class="modal">
    <h2>Rendelés véglegesítése</h2>
    
    <!-- ----------- RENDELÉS INFÓK BLOKK ----------- -->
    <div class="rendeles-info">
        <p><strong>Megrendelő:</strong> <?= htmlspecialchars($nev) ?> (<?= htmlspecialchars($felhasznalo_email) ?>)</p>
        
        <?php if (!empty($rendeles_megjegyzes)): ?>
            <p><strong>Megjegyzés:</strong> <?= nl2br(htmlspecialchars($rendeles_megjegyzes)) ?></p>
        <?php endif; ?>

        <p><strong>Szállítási cím:</strong> <?= htmlspecialchars($cim) ?></p>
        <p><strong>Szállítási partner:</strong> <?= htmlspecialchars($partner_nev) ?> (<?= $szallitas_ar ?> Ft)</p>
        
        <?php if (!empty($rendeles_megjegyzes)): ?>
            <p><strong>Megjegyzés:</strong> <?= nl2br(htmlspecialchars($rendeles_megjegyzes)) ?></p>
        <?php endif; ?>

        <!-- ----------- TERMÉKEK LISTÁJA ----------- -->
        <p><strong>Termékek:</strong></p>
        <ul>
            <?php foreach ($_SESSION['veglegesites_adatok']['termekek'] as $termek): ?>
                <li><?= htmlspecialchars($termek['nev']) ?> x <?= $termek['mennyiseg'] ?> db = <?= $termek['reszosszeg'] ?> Ft</li>
            <?php endforeach; ?>
        </ul>

        <!-- ----------- VÉGÖSSZEG MEGJELENÍTÉSE ----------- -->
        <p><strong>Végösszeg (termék + szállítás):</strong> <?= $_SESSION['veglegesites_adatok']['vegosszeg'] ?> Ft</p>
    </div>

    <!-- ----------- NAVIGÁCIÓS GOMBOK ----------- -->
    <div class="gomb-container">
        <!-- Vissza link -->
        <a href="szallitas_cim.php" class="vissza">← Vissza</a>
        
        <!-- Rendelés leadása form -->
        <form action="rendeles_sikeres.php" method="post">
            <button type="submit">Rendelés leadása</button>
        </form>
    </div>
</div>
</body>
</html>