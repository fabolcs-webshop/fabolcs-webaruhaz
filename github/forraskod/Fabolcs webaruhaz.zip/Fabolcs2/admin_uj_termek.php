<?php
session_start();
require_once 'adatbazis.php';

// Bejelentkezés és admin jogosultság ellenőrzés
if (!isset($_SESSION['felhasznalo_id'])) {
    header("Location: bejelentkezes.php");
    exit();
}

$felhasznalo_id = $_SESSION['felhasznalo_id'];
$admin_stmt = $adatbazis->prepare("SELECT admin FROM felhasznalok WHERE id = ?");
$admin_stmt->bind_param("i", $felhasznalo_id);
$admin_stmt->execute();
$admin_stmt->bind_result($admin);
$admin_stmt->fetch();
$admin_stmt->close();

if (!$admin) {
    echo "Nincs jogosultságod az oldal eléréséhez.";
    exit();
}

$uzenet = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nev = trim($_POST['nev']);
    $leiras = trim($_POST['leiras']);
    $ar = (int)$_POST['ar'];
    $kep = $_FILES['kep'];
    $celutvonal = '';

    if ($kep['error'] === UPLOAD_ERR_OK) {
        $fajlnev = basename($kep['name']);
        $celutvonal = "kepek/" . $fajlnev;
        move_uploaded_file($kep['tmp_name'], $celutvonal);
    }

    $stmt = $adatbazis->prepare("INSERT INTO termekek (nev, leiras, ar, kep) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssis", $nev, $leiras, $ar, $celutvonal);
    if ($stmt->execute()) {
        $uzenet = "✔️ Termék sikeresen hozzáadva!";
    } else {
        $uzenet = "❌ Hiba a termék mentése során.";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Termék hozzáadása</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
        /* Egyedi betűtípus betöltése */
       @font-face {
    font-family: 'Distant Stroke';
    src: url('fonts/Distant_Stroke.otf') format('opentype');
    font-weight: normal;
    font-style: normal;
}

        /* Alap body stílusok: teljes oldal, háttér, betűtípus */
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            background-color: #4b2e1e; /* sötétbarna háttér */
            position: relative;
            min-height: 100vh;
        }

        /* Háttér képpel faerezet mintával, fix pozícióban */
        body::after {
            content: "";
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            background: url('kepek/erezet2.jpg') repeat;
            z-index: -1; /* hátra kerül */
        }

        /* Nagy, középre igazított logó doboz a tetején */
        .logo-box {
            background: #5c3a2e; /* sötétbarna */
            border-radius: 12px; /* lekerekített sarkok */
            padding: 10px 30px;
            margin: 30px auto 10px; /* felül nagy margó, alul kicsi, középre */
            max-width: 720px; /* max szélesség */
            width: 95%; /* mobilbarát szélesség */
            text-align: center;
            font-family: 'Distant Stroke', sans-serif; /* egyedi betűtípus */
            font-size: 80px;
            color: #ffffff; /* fehér szöveg */
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2); /* árnyék */
        }

        /* Modal box, ahol a form helyezkedik el */
        .modal-box {
            background: #f5f5dc; /* világos bézs háttér */
            border-radius: 12px;
            padding: 30px;
            max-width: 720px;
            width: 95%;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
        }

        /* Modal cím stílusa, nagy, vastag, középre */
        .modal-title {
            font-size: 28px;
            font-weight: bold;
            text-align: center;
            margin-bottom: 20px;
        }

        /* Form elemek oszlopba rendezve, 15px hézaggal */
        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        /* Label címkék félkövérek */
        label {
            font-weight: bold;
        }

        /* Input, textarea, file input egységes stílusban:
           - belső párnázás
           - lekerekített sarkok
           - szürke keret
           - teljes szélesség */
        input[type="text"], input[type="number"], textarea, input[type="file"] {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            width: 100%;
        }/* Alap gombstílus:
   - Kényelmes belső padding
   - Sötétbarna háttér, fehér szöveg
   - Nincs keret
   - Lekerekített sarkok
   - Vastag betű és kattintható mutató */
button {
    padding: 10px;
    background-color: #5c3a2e;
    color: white;
    border: none;
    border-radius: 5px;
    font-weight: bold;
    cursor: pointer;
}

/* Gombokat tartalmazó konténer:
   - Flexbox, középre igazítás
   - 10px hézag a gombok között
   - Felülről margó */
.gombok {
    display: flex;
    justify-content: center;
    gap: 10px;
    margin-top: 20px;
}

/* Gomb kinézet linkeknek:
   - Padding a kényelmes megjelenéshez
   - Sötétbarna háttér, fehér szöveg
   - Lekerekített sarkok
   - Vastag betű */
.gombok a {
    padding: 10px 20px;
    background-color: #5c3a2e;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    font-weight: bold;
}

/* Üzenet megjelenítése:
   - Középre igazított szöveg
   - Alsó margó
   - Vastag betű */
.uzenet {
    text-align: center;
    margin-bottom: 15px;
    font-weight: bold;
}
</style>
</head>
<body>

<!-- Nagy logó a fejlécben -->
<div class="logo-box">Fabolcs</div>

<!-- Modal doboz -->
<div class="modal-box">
    <!-- Modal cím -->
    <div class="modal-title">Új termék hozzáadása</div>

    <!-- Siker vagy hibaüzenet megjelenítése -->
    <?php if ($uzenet): ?><div class="uzenet"><?= $uzenet ?></div><?php endif; ?>

    <!-- Termék hozzáadási űrlap (file feltöltéssel) -->
    <form method="post" enctype="multipart/form-data">

        <!-- Termék neve -->
        <label for="nev">Termék neve:</label>
        <input type="text" name="nev" id="nev" required>

        <!-- Leírás -->
        <label for="leiras">Leírás:</label>
        <textarea name="leiras" id="leiras" rows="4" required></textarea>

        <!-- Ár -->
        <label for="ar">Ár (Ft):</label>
        <input type="number" name="ar" id="ar" required>

        <!-- Kép feltöltése -->
        <label for="kep">Kép feltöltése:</label>
        <input type="file" name="kep" id="kep" accept="image/*">

        <!-- Mentés gomb -->
        <button type="submit">Mentés</button>
    </form>

    <!-- Navigációs gombok -->
    <div class="gombok">
        <a href="index.php">Főoldal</a>
        <a href="admin_termekek.php">Termékek</a>
    </div>
</div>
</body>
</html>