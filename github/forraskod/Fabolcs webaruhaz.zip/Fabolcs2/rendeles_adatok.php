<?php
session_start();
// Ellenőrizzük, hogy a felhasználó be van-e jelentkezve
if (!isset($_SESSION['felhasznalo_id'])) {
    // Ha nincs bejelentkezve, átirányítjuk a bejelentkezési oldalra
    header("Location: bejelentkezes.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Szállítási adatok</title>
    <style>
        /* Jobbra igazított státusz megjelenítés a fejlécben */
        .status {
            text-align: right;
            margin: 10px 20px;
        }
    </style>
</head>
<body>

    <div class="status">
        <?php if (isset($_SESSION['felhasznalo_email'])): ?>
            <!-- Megjelenítjük a bejelentkezett felhasználó email címét és kijelentkezési linket -->
            Bejelentkezve mint: <strong><?= htmlspecialchars($_SESSION['felhasznalo_email']) ?></strong>
            | <a href="kijelentkezes.php">Kijelentkezés</a>
        <?php endif; ?>
    </div>

    <h1>Szállítási és vevői adatok</h1>

    <!-- Szállítási adatok megadása űrlap -->
    <form action="rendeles_mentes.php" method="post">
        <label>Vezetéknév: <input type="text" name="vezeteknev" required></label><br><br>
        <label>Keresztnév: <input type="text" name="keresztnev" required></label><br><br>
        <label>Cím: <input type="text" name="cim" required></label><br><br>
        <label>Város: <input type="text" name="varos" required></label><br><br>
        <label>Irányítószám: <input type="text" name="iranyitoszam" required></label><br><br>
        <label>Telefonszám: <input type="text" name="telefon" required></label><br><br>
        <button type="submit">Rendelés leadása</button>
    </form>

    <!-- Vissza gomb a kosár oldalra, inline formban -->
    <form action="kosar.php" method="get" style="display: inline;">
        <button type="submit">← Vissza a kosárhoz</button>
    </form>
</body>
</html>