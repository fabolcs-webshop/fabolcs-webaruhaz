<!DOCTYPE html>
<html lang="hu">
<head>
<meta charset="UTF-8">
<title>Diódás lézer</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
@font-face {
    font-family: 'Distant Stroke';
    src: url('fonts/Distant_Stroke.otf') format('opentype');
    font-weight: normal;
    font-style: normal;
}
body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
    background-color: #4b2e1e;
    position: relative;
    min-height: 100vh;
}
body::after {
    content: "";
    position: fixed;
    top: 0; left: 0;
    width: 100%; height: 100%;
    background: url('kepek/erezet2.jpg') repeat;
    z-index: -1;
}
.logo-box {
    background: #5c3a2e;
    border-radius: 12px;
    padding: 10px 30px;
    margin: 30px auto 10px;
    max-width: 720px;
    width: 95%;
    text-align: center;
    font-family: 'Distant Stroke', sans-serif;
    font-size: 80px;
    color: #ffffff;
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
}
.vissza-link-container {
    text-align: center;
    margin: 20px auto;
}
.vissza-link {
    display: inline-block;
    padding: 10px 20px;
    background-color: #5c3a2e;
    color: white;
    border-radius: 5px;
    font-weight: bold;
    text-decoration: none;
}
.vissza-link:hover {
    background-color: #3e251b;
}
.modal-box {
    background: #f5f5dc;
    border-radius: 12px;
    max-width: 900px;
    width: 95%;
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
    margin: 20px auto;
    display: flex;
    flex-direction: column;
    max-height: 80vh;
}
.modal-header {
    padding: 20px 30px 10px;
    text-align: center;
}
.modal-header h2 {
    margin: 0;
    font-size: 36px;
    color: #5c3a2e;
}
.modal-content {
    flex: 1;
    overflow-y: auto;
    padding: 10px 20px;
    display: flex;
    gap: 20px;
    max-height: 60vh;
    box-sizing: border-box;
}
.modal-images {
    flex: 0 0 35%;
    text-align: center;
}
.modal-images img {
    max-width: 100%;
    height: auto;
    margin: 10px 0;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}
#typewriter {
    flex: 1;
    overflow-y: auto;
    white-space: pre-wrap;
    font-size: 16px;
    line-height: 1.5;
    color: #222;
    padding-right: 5px;
}
.type-glow {
    color: #5c3a2e;
    text-shadow: 0 0 5px #5c3a2e, 0 0 10px #5c3a2e;
}
.fust-container {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 0;
    overflow: visible;
    pointer-events: none;
    z-index: 10;
}
.fust-pamacs {
    position: absolute;
    bottom: 0;
    width: 50px;
    height: 50px;
    background: rgba(90, 70, 50, 0.2);
    border-radius: 50%;
    animation: fustFel 10s forwards;
    opacity: 0.95;
}
@keyframes fustFel {
    0% { transform: translateY(0) scale(1); opacity: 0.95; }
    100% { transform: translateY(-250px) scale(2.5); opacity: 0; }
}
@media (max-width: 768px) {
    .modal-content {
        flex-direction: column;
        gap: 10px;
    }
    .modal-images, #typewriter {
        flex: none;
        max-width: 100%;
    }
}
</style>
</head>
<body>
<div class="logo-box">Fabolcs</div>
<div class="vissza-link-container">
    <a href="index.php" class="vissza-link">← Vissza a főoldalra</a>
</div>
<div class="modal-box">
    <div class="modal-header">
        <h2>Diódás lézer</h2>
    </div>
    <div class="modal-content">
        <div class="modal-images">
            <img src="kepek/ortur.jpg" alt="Lézerfej modul">
            <img src="kepek/master.jpg" alt="Lézervágó gép">
        </div>
        <div id="typewriter"></div>
        <div class="fust-container" id="fustContainer"></div>
    </div>
</div>

<script>
// Szöveg egyben megjelenítve
document.addEventListener("DOMContentLoaded", () => {
    const typeContainer = document.getElementById("typewriter");
    const fustContainer = document.getElementById("fustContainer");

    const text = `A kék lézer olyan lézer, amely 360 és 480 nanométer közötti hullámhosszú elektromágneses sugárzást bocsát ki, amelyet az emberi szem kéknek vagy ibolyaszínnek lát. A kék sugarakat hélium-kadmium gázlézerek állítják elő 441,6 nm-en, és argon-ion lézerek 458 és 488 nm-en. A kék sugarú félvezető lézerek jellemzően gallium(III)-nitridre (GaN; lila színű) vagy indium-gallium-nitridre épülnek (gyakran valódi kék színű, de más színek előállítására is képesek). Mind a kék, mind a lila lézer megszerkeszthető az infravörös lézer hullámhosszának frekvencia-duplázásával diódalézerek vagy diódapumpás szilárdtestlézerek segítségével. A 445 nm-es fényt kibocsátó dióda lézerek egyre népszerűbbek kézi lézerként. A 445 nm alatti hullámhosszt kibocsátó lézerek ibolyának tűnnek (de néha kék lézernek is nevezik). A kereskedelemben legelterjedtebb kék lézerek közé tartoznak a Blu-ray alkalmazásokban használt dióda lézerek, amelyek 405 nm-es "ibolya" fényt bocsátanak ki, ami elég rövid hullámhossz ahhoz, hogy egyes vegyi anyagokban fluoreszcenciát okozzon, ugyanúgy, mint a sugárzás tovább az ultraibolya sugárzásba. ("fekete fény") igen. A 400 nm-nél rövidebb hullámhosszú fény ultraibolya sugárzásnak minősül. A kék lézerfényt alkalmazó eszközök számos területen alkalmazhatók, a nagy sűrűségű optoelektronikai adattárolástól az orvosi alkalmazásokig.

Lézergravírozó eszközök közül ezek gyengébbek mint a CO2 lézer, de megfelelően alkalmazhatók fa, fém, akril, plexi, stb gravírozására is. Noha ártalmatlannak tűnik, a kék fény lézer különösen veszélyes a szemre, fontos a megfelelő kabin, védőszemüveg használata.A lézergravírozás során egy koncentrált lézersugár hatására az anyag elpárolog vagy elég. Ezzel rendkívül tartós, jól látható és olvasható felirat, logó, kép, sorszám vagy akár vonalkód készíthető, szinte bármilyen anyagra. Felhasználási módja rendkívül széles körű. Leggyakrabban személyre szóló ajándéktárgyakat készítenek, de ipari körökben gravírozással történhet a különböző eszközök márkanévvel történő ellátása, szerszámok, vagy alkatrészek sorszámozása. A lézersugárnak köszönhetően kis méretű felületekre is nagy pontossággal lehet gravírozni. Stabilitás és pontosság jellemzi ezt az emblémázási technológiát.Forrás:(https://hu.wikipedia.org/wiki/Lézergravírozás)`; 

    typeContainer.textContent = text;

    // Folyamatos füstgenerálás
    function generateFust() {
        const fust = document.createElement('div');
        fust.className = 'fust-pamacs';
        fust.style.left = Math.random() * 90 + "%";
        fustContainer.appendChild(fust);
        setTimeout(() => fust.remove(), 10000);
        const nextDelay = Math.random() * 600 + 200; // 200–800 ms között
        setTimeout(generateFust, nextDelay);
    }

    generateFust();
});
</script>
</body>
</html>