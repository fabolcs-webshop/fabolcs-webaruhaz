<?php
// MINDEN oldal elején session indítás, hogy a felhasználói állapot (bejelentkezés, kosár) megmaradjon
session_start();

// Adatbáziskapcsolatot behúzzuk egy külön fájlból
require_once 'adatbazis.php';

// ----------- Kosár darabszám változó inicializálása -----------
$kosar_darab = 0;

// ------------ Ellenőrzés: Be van-e jelentkezve a felhasználó ------------
if (isset($_SESSION['felhasznalo_id'])) {
    // Bejelentkezett felhasználó esetén az adatbázisból számoljuk össze a kosárban lévő darabszámot
    $felhasznalo_id = $_SESSION['felhasznalo_id'];
    
    // SQL lekérdezés előkészítése
    $stmt = $adatbazis->prepare("SELECT SUM(mennyiseg) FROM kosar_tetelek WHERE felhasznalo_id = ?");
    $stmt->bind_param("i", $felhasznalo_id);
    $stmt->execute();
    $stmt->bind_result($ossz_db);
    $stmt->fetch();

    // Kosár darabszámot beállítjuk
    $kosar_darab = (int)$ossz_db;
    $stmt->close();

} elseif (isset($_SESSION['kosar']) && is_array($_SESSION['kosar'])) {
    // Ha nincs bejelentkezve, de SESSION-ben tárolt kosara van → vendég kosár
    // Egyszerűen összeadjuk az értékeket a tömbben
    $kosar_darab = array_sum($_SESSION['kosar']);
}

// ----------- Terméklista lekérdezése adatbázisból -----------
$sql = "SELECT * FROM termekek";
$eredmeny = $adatbazis->query($sql);

// Ha hiba történik a lekérdezéskor, leállítjuk a futást hibaüzenettel
if (!$eredmeny) {
    die("Hiba a lekérdezésben: " . $adatbazis->error);
}

// ----------- Admin jogosultság változó alapértelmezett értéke -----------
$admin = 0;

// ----------- Ellenőrizzük, hogy a felhasználó admin-e -----------
if (isset($_SESSION['felhasznalo_id'])) {
    $id = $_SESSION['felhasznalo_id'];

    // Lekérdezzük a felhasználó admin státuszát
    $admin_stmt = $adatbazis->prepare("SELECT admin FROM felhasznalok WHERE id = ?");
    $admin_stmt->bind_param("i", $id);
    $admin_stmt->execute();
    $admin_stmt->bind_result($admin);
    $admin_stmt->fetch();
    $admin_stmt->close();
}

// ----------- Admin felületen új üzenetek száma (olvasatlan) -----------
$uzenetek_db = 0;
if ($admin) {
    // Csak adminoknak számoljuk ki
    $stmt = $adatbazis->prepare("SELECT COUNT(*) FROM egyedi_keresek WHERE olvasott = 0");
    $stmt->execute();
    $stmt->bind_result($uzenetek_db);
    $stmt->fetch();
    $stmt->close();
}

// ----------- Admin felületen új rendelések száma (statusz = 'uj') -----------
$uj_rendelesek_db = 0;
if ($admin) {
    $stmt = $adatbazis->prepare("SELECT COUNT(*) FROM uj_rendelesek WHERE statusz = 'uj'");
    $stmt->execute();
    $stmt->bind_result($uj_rendelesek_db);
    $stmt->fetch();
    $stmt->close();
}

// ----------- Admin felületen új fiókkezelési kérelmek száma (feldolgozatlan) -----------
$uj_fiokkezeles_db = 0;
if ($admin) {
    $stmt = $adatbazis->prepare("SELECT COUNT(*) FROM fiok_torlesi_kerelmek WHERE feldolgozatlan = 1");
    $stmt->execute();
    $stmt->bind_result($uj_fiokkezeles_db);
    $stmt->fetch();
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
<meta charset="UTF-8">
<title>Fabolcs Webáruház</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>
/* --------- EGYEDI BETŰTÍPUS BETÖLTÉSE --------- */
@font-face {
    font-family: 'Distant Stroke';
    src: url('fonts/Distant_Stroke.otf') format('opentype');
    font-weight: normal;
    font-style: normal;
}

/* --------- ALAP BODY STÍLUS --------- */
body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
    background-color: #4b2e1e;    /* Sötétbarna alapszín */
    position: relative;
    min-height: 100vh;            /* Minimum teljes képernyő magasság */
}

/* --------- FAKÉREG HATÁSÚ HÁTTÉRKÉP --------- */
body::after {
    content: "";
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: url('kepek/erezet2.jpg') repeat; /* ismétlődő faerezet minta */
    z-index: -1;                    /* hátra kerül a tartalom mögé */
}

/* --------- LOGO-BOX STÍLUS --------- */
.logo-box {
    background: #5c3a2e;            /* Sötétbarna háttér */
    border-radius: 12px;            /* Lekerekített sarkok */
    padding: 10px 30px;             /* Belső margó */
    margin: 30px auto 10px;         /* Fent és alul margó, középre igazítás */
    max-width: 720px;               /* Maximum szélesség nagy képernyőn */
    width: 95%;                     /* Mobilbarát rugalmas szélesség */
    text-align: center;             /* Középre igazított szöveg */
    font-family: 'Distant Stroke', sans-serif; /* Egyedi betűtípus */
    font-size: 80px;                /* Nagy logófelirat */
    color: #ffffff;                 /* Fehér szöveg */
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2); /* Finom árnyék alatta */
}

/* --------- NAVIGÁCIÓ MENÜ SÁV --------- */
.navigacio {
    display: flex;
    justify-content: center;        /* Középre igazított linkek */
    align-items: center;
    gap: 15px;                      /* Linkek közti hézag */
    margin: 10px auto 20px;         /* Kívül margó */
    flex-wrap: wrap;                /* Több sorba törhető mobilon */
}

/* --------- NAVIGÁCIÓ LINK ÉS GOMB STÍLUS --------- */
.navigacio a, .navigacio button {
    padding: 10px 20px;             /* Belső margó, nagyobb kattinthatóság */
    background-color: #5c3a2e;      /* Sötétbarna háttér */
    color: #ffffff;                 /* Fehér szöveg */
    text-decoration: none;          /* Link aláhúzás kikapcsolva */
    border-radius: 5px;             /* Lekerekített sarkok */
    font-weight: bold;
    border: 2px solid #5c3a2e;      /* Szépen kiemelt keret */
    cursor: pointer;
    transition: background-color 0.3s, color 0.3s; /* Szép átmenet hoverkor */
}

/* --------- NAVIGÁCIÓ LINK / GOMB HOVER EFFEKT --------- */
.navigacio a:hover, .navigacio button:hover {
    background-color: #f5f5dc;      /* Világosabb háttér hoverkor */
    color: #5c3a2e;                  /* Sötétbarna szöveg hoverkor */
}

/* --------- KOSÁR BADGE (SZÁMLÁLÓ KÖR) --------- */
.kosar-badge {
    background: #fff7e6;            /* Világos bézs háttér */
    color: #5c3a2e;                 /* Sötétbarna szöveg */
    font-size: 12px;                /* Kisebb szöveg */
    padding: 2px 6px;               /* Kicsi belső margó */
    border-radius: 50%;             /* Tökéletes kör alak */
    font-weight: bold;
    border: 1px solid #5c3a2e;      /* Finom barna keret */
}

/* ----------- TERMÉKEK GRID KONTAINER ----------- */
.termekek-container {
    display: grid;                                  /* Rács (grid) elrendezés */
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    /* Automatikusan több oszlop, min. 220px szélességgel, 1fr arányban kitöltve */
    gap: 20px;                                      /* Rácselemek közötti távolság */
    padding: 20px;                                  /* Belső margó a konténeren belül */
    max-width: 1200px;                              /* Legnagyobb szélesség */
    margin: 20px auto;                              /* Középre igazítás */
    box-sizing: border-box;                         /* Padding is beleszámít a szélességbe */
}

/* ----------- TERMÉK KÁRTYA ----------- */
.termek {
    background: #f5f5dc;                            /* Világos bézs háttér */
    padding: 15px;                                  /* Belső margó */
    border-radius: 12px;                            /* Lekerekített sarkok */
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);      /* Lágy árnyék */
    display: flex;
    flex-direction: column;                         /* Függőleges elrendezés */
    transition: transform 0.3s ease;                /* Simán nagyít hoverkor */
}

/* ----------- Hover effekt: enyhe nagyítás ----------- */
.termek:hover {
    transform: scale(1.02);
}

/* ----------- TERMÉK KÉP ----------- */
.termek img {
    width: 100%;                                    /* Szélesség teljesen kitöltve a konténeren belül */
    max-width: 200px;                               /* Maximum szélesség */
    border-radius: 8px;                             /* Lekerekített sarkok */
    object-fit: cover;                              /* Kitölti a keretet a képarány megtartásával */
    margin: 15px 0;
    display: block;
    margin: 15px auto;                              /* Középre igazítás */
}

/* ----------- TERMÉK CÍM ----------- */
.termek h3 {
    margin: 10px 0 5px;
    color: #5c3a2e;                                 /* Sötétbarna szín */
    font-size:18px;
    text-align: center;
}

/* ----------- TERMÉK LEÍRÁS, ÁR ----------- */
.termek p {
    margin: 5px 0;
    color: #333; 
    text-align: center;                                   /* Sötétszürke szöveg */
}

/* ----------- KOSÁRBA ŰRLAP KONTAINER ----------- */
.termek form {
    margin-top: auto;                               /* Aljára tolja a gombot a flex oszlopban */
    display: flex;
    flex-direction: column;
    gap: 10px;                                      /* Űrlap elemei közötti hézag */
}

/* ----------- KOSÁRBA GOMB ----------- */
.termek button {
    padding: 8px 16px;
    background-color: #5c3a2e;                      /* Sötétbarna */
    color: white;
    border: none;
    border-radius: 5px;
    font-weight: bold;
    cursor: pointer;
    
}

/* ----------- GOMB HOVER ----------- */
.termek button:hover {
    background-color: #4b2e1e;                      /* Még sötétebb barna hoverkor */
}

/* ----------- MENNYISÉG-VÁLASZTÓ DOBOZ ----------- */
.mennyiseg-box {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;                                      /* A gombok és az input közötti hézag */
}

/* ----------- MENNYISÉG-VÁLASZTÓ GOMBOK ----------- */
.mennyiseg-box button {
    background-color: #5c3a2e;
    color: white;
    border: none;
    border-radius: 5px;
    width: 40px;                                    /* Négyzet alakú gomb */
    height: 40px;
    font-size: 22px;                                /* Nagy + / - jel */
    font-weight: bold;
    cursor: pointer;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 0;
}

/* ----------- MENNYISÉG INPUT MEZŐ ----------- */
.mennyiseg-box input {
    width: 50px;
    text-align: center;                             /* A szám középen jelenjen meg */
    font-size: 16px;
    border: 1px solid #ccc;                         /* Finom szürke keret */
    border-radius: 5px;
    padding: 5px;
}

/* -------- MODÁL ALAP BEÁLLÍTÁS -------- */
.modal {
    display: none;                        /* Alapból rejtett (JS-el jelenítjük meg) */
    position: fixed;                      /* Képernyőn fixen helyezkedik el */
    top: 0; left: 0;
    width: 100%; height: 100%;            /* Teljes képernyőt lefedi */
    background: rgba(0,0,0,0.6);          /* Átlátszó fekete háttér – overlay hatás */
    justify-content: center;              /* Flexbox – vízszintesen középre */
    align-items: center;                  /* Flexbox – függőlegesen középre */
    z-index: 999;                         /* Magas z-index, minden elé kerül */
}

/* -------- MODÁL TARTALOM DOBOZ -------- */
.modal-content {
    background: #f5f5dc;                  /* Bézs háttér */
    padding: 25px;                        /* Belső margó */
    max-width: 400px;                     /* Maximum szélesség nagy képernyőn */
    width: 90%;                           /* Mobilbarát rugalmas szélesség */
    border-radius: 12px;                  /* Lekerekített sarkok */
    box-shadow: 0 8px 30px rgba(0,0,0,0.3); /* Finom árnyék */
}

/* -------- MODÁL BEZÁRÓ X GOMB -------- */
.modal-close {
    float: right;
    font-size: 20px;                      /* Nagyobb X ikon */
    cursor: pointer;
    color: #5c3a2e;                       /* Sötétbarna szín */
}

/* -------- MODÁL GOMB ALAP STÍLUS -------- */
.modal-box button,
.modal-content button {
    padding: 10px 20px;
    background-color: #5c3a2e;            /* Barna háttér */
    color: white;
    border-radius: 5px;
    border: 2px solid #5c3a2e;
    font-weight: bold;
    cursor: pointer;
    transition: background-color 0.3s, color 0.3s;  /* Hover átmenet */
}

/* -------- MODÁL GOMB HOVER EFFEKT -------- */
.modal-box button:hover,
.modal-content button:hover {
    background-color: #f5f5dc;            /* Hoverkor világosabb háttér */
    color: #5c3a2e;                       /* Hoverkor barna szöveg */
}

/* -------- MEDIA QUERY – MOBILBARÁT NAVIGÁCIÓ -------- */
@media screen and (max-width: 600px) {
    .navigacio {
        flex-wrap: wrap;                  /* Több sorba törhető */
        justify-content: center;
        gap: 10px;
        padding: 5px;
    }

    .navigacio a, .navigacio button {
        flex: 1 1 40%;                    /* Rugalmas szélesség 40% */
        max-width: 45%;
        padding: 8px 12px;
        font-size: 14px;
    }
}

/* -------- BEJELENTKEZÉS LINK STÍLUS -------- */
.bejelentkezes-link {
    display: inline-block;
    padding: 8px 16px;
    background-color: #5c3a2e;            /* Barna háttér */
    color: white;
    text-decoration: none;                 /* Link aláhúzás kikapcsolva */
    border-radius: 5px;
    font-weight: bold;
    border: 2px solid #5c3a2e;
    transition: background-color 0.3s, color 0.3s;
}

/* -------- BEJELENTKEZÉS LINK HOVER EFFEKT -------- */
.bejelentkezes-link:hover {
    background-color: #f5f5dc;             /* Hoverkor világos háttér */
    color: #5c3a2e;                        /* Hoverkor barna szöveg */
}
/* -------- MODÁL TARTALOM TESTE - KÉT OSZLOP -------- */
.modal-body {
    display: flex;                      /* Flexbox elrendezés */
    gap: 20px;                          /* Két oszlop közti távolság */
    align-items: flex-start;            /* Fent igazítva kezdődik a tartalom */
    flex-wrap: wrap;                    /* Mobilon törhet több sorba */
}

/* -------- MODÁL BODYBEN LÉVŐ EGY-EGY OSZLOP -------- */
.modal-body > div {
    flex: 1 1 250px;                    /* Rugalmas szélesség min. 250px */
    min-width: 200px;                   /* Soha ne menjen 200 alá */
}

/* -------- NAGY LOGÓ A MODÁLBAN -------- */
.modal-logo-big {
    font-family: 'Distant Stroke', sans-serif;  /* Egyedi betűtípus */
    color: #5c3a2e;                            /* Barna szín */
    font-size: 80px;                           /* Nagy méretű logó felirat */
    text-align: center;                        /* Középre igazítás */
    flex-shrink: 0;                            /* Ne nyomódjon össze kisebb képernyőn sem */
}

/* -------- MODÁL KÖZPONTI TARTALOM ALAP STÍLUS -------- */
.modal-content {
    background: #f5f5dc;                       /* Bézs háttérszín */
    padding: 25px;
    max-width: 400px;                          /* Maximum szélesség nagy képernyőn */
    width: 90%;                                /* Mobilbarát rugalmas szélesség */
    border-radius: 12px;                       /* Lekerekített sarkok */
    box-shadow: 0 8px 30px rgba(0,0,0,0.3);    /* Finom árnyék */
    text-align: center;                        /* Szöveg középre */
}

/* -------- MODÁL CÍM STÍLUS -------- */
.modal-title {
    font-family: 'Distant Stroke', sans-serif; /* Egyedi logó betűtípus */
    color: #5c3a2e;                            /* Barna szín */
    font-size: 36px;                           /* Nagy cím méret */
    margin-bottom: 20px;                       /* Alatta távolság */
}

/* -------- MODÁL ŰRLAP KONTAINER -------- */
.modal-form {
    display: flex;                             /* Flex oszlopos elrendezés */
    flex-direction: column;
    gap: 12px;                                 /* Input mezők közötti távolság */
    align-items: center;                       /* Középre igazítva */
}

/* -------- MODÁL ŰRLAP INPUT MEZŐK -------- */
.modal-form input {
    width: 100%;                               /* Alapból 100%, de max 300px */
    max-width: 300px;
    padding: 10px;                             /* Belső margó kényelmes gépeléshez */
    border: 1px solid #ccc;                    /* Szürke szegély */
    border-radius: 5px;                        /* Lekerekített sarkok */
}

/* -------- MODÁL ŰRLAP GOMB -------- */
.modal-form button {
    padding: 10px 20px;                        /* Belső margó a kattinthatósághoz */
    background-color: #5c3a2e;                 /* Sötétbarna háttérszín */
    color: white;                              /* Fehér szöveg */
    border-radius: 5px;                        /* Lekerekített sarkok */
    border: 2px solid #5c3a2e;                 /* Szépen kiemelt szegély */
    font-weight: bold;
    cursor: pointer;
    transition: background-color 0.3s, color 0.3s; /* Simán vált színt hoverkor */
    margin-top: 10px;                          /* Felülről távolság */
}

/* -------- MODÁL ŰRLAP GOMB HOVER EFFEKT -------- */
.modal-form button:hover {
    background-color: #f5f5dc;                 /* Hoverkor világos háttér */
    color: #5c3a2e;                            /* Hoverkor barna szöveg */
}
</style>
</head>
<body>
<!-- --------- LOGO FELIRAT --------- -->
<div class="logo-box">Fabolcs</div>

<!-- --------- FŐ NAVIGÁCIÓ --------- -->
<div class="navigacio">
    
   <?php if ($admin): ?>
       <!-- Ha admin felhasználó van bejelentkezve, admin menüpontokat mutat -->
       <a href="admin_uj_termek.php">Termék hozzáadás</a>
       
       <a href="admin.php">
           Rendelések kezelése
           <?php if ($uj_rendelesek_db > 0): ?>
               <!-- Ha van új rendelés, badge-ben megmutatjuk -->
               <span class="kosar-badge"><?= $uj_rendelesek_db ?></span>
           <?php endif; ?>
       </a>
       
       <a href="admin_termekek.php">Feltöltött termékek</a>
       
       <a href="fiok_kezeles.php">
           Fiók kezelése
           <?php if ($uj_fiokkezeles_db > 0): ?>
               <!-- Ha van új fiókkezelési kérelem, badge -->
               <span class="kosar-badge"><?= $uj_fiokkezeles_db ?></span>
           <?php endif; ?>
       </a>
       
       <a href="uzenetek.php">
           Üzenetek
           <span class="kosar-badge"><?= $uzenetek_db ?></span>
       </a>
       
       <a href="kijelentkezes.php">Kijelentkezés</a>

   <?php elseif (!isset($_SESSION['felhasznalo_id'])): ?>
       <!-- Ha nincs bejelentkezve -->
       <a href="lezervagasrol.php">Lézervágás</a>
       <a href="egyedi.php">Egyedi elképzelés</a>
       <a href="kapcsolat.php">Kapcsolat</a>
       <a href="szallitas.php">Szállítás</a>
       <button onclick="megnyitLoginModalt()">Bejelentkezés</button>
       <button onclick="megnyitModalt()">Regisztráció</button>

   <?php else: ?>
       <!-- Ha sima vásárló be van jelentkezve -->
       <a href="lezervagasrol.php">Lézervágás</a>
       <a href="egyedi.php">Egyedi elképzelés</a>
       <a href="kapcsolat.php">Kapcsolat</a>
       <a href="szallitas.php">Szállítás</a>
       
       <a href="kosar.php">
           🛒 Kosaram
           <?php if ($kosar_darab > 0): ?>
               <!-- Kosár badge, ha van benne termék -->
               <span class="kosar-badge"><?= $kosar_darab ?></span>
           <?php endif; ?>
       </a>
       
       <a href="vasarlo_fiok.php">Fiókom</a>
       <a href="kijelentkezes.php">Kijelentkezés</a>
   <?php endif; ?>
</div>

<!-- --------- TERMÉKEK GRID KONTAINER --------- -->
<main class="termekek-container">
    <?php if ($eredmeny->num_rows === 0): ?>
        <!-- Ha nincs termék az adatbázisban -->
        <p style="text-align: center; color: #fff;">Nincs megjeleníthető termék.</p>
    <?php endif; ?>

    <!-- Termékek kilistázása ciklussal -->
    <?php while($sor = $eredmeny->fetch_assoc()): ?>
        <div class="termek">
            <h3><?= htmlspecialchars($sor['nev']) ?></h3>

            <?php
            // Kép elérési út ellenőrzése
            $kep_fajl = basename($sor['kep']);
            $kep_utvonal = "kepek/" . $kep_fajl;

            if (!empty($kep_fajl) && file_exists($kep_utvonal)): ?>
                <!-- Ha a kép létezik a szerveren -->
                <img src="<?= htmlspecialchars($kep_utvonal) ?>" alt="Termékkép">
            <?php else: ?>
                <!-- Ha nincs kép -->
                <p><em>Nincs kép</em></p>
            <?php endif; ?>

    <!-- -------- TERMÉK LEÍRÁS ÉS ÁR -------- -->
<p><?= nl2br(htmlspecialchars($sor['leiras'])) ?></p>
<p><strong>Ár:</strong> <?= $sor['ar'] ?> Ft</p>

<?php if (isset($_SESSION['felhasznalo_id']) && !$admin): ?>
    <!-- SIMA FELHASZNÁLÓ: KOSÁRBA RAKÁS -->
    <form method="post" action="kosar_hozzaad.php">
        <input type="hidden" name="termek_id" value="<?= $sor['id'] ?>">
        <div class="mennyiseg-box">
            <button type="button" onclick="csokkent(<?= $sor['id'] ?>)">−</button>
            <input type="number" name="mennyiseg" id="mennyiseg_<?= $sor['id'] ?>" value="1" min="1" readonly>
            <button type="button" onclick="novel(<?= $sor['id'] ?>)">+</button>
        </div>
        <button type="submit" class="kosarba-gomb">Kosárba teszem</button>
    </form>

<?php elseif ($admin): ?>
    <!-- ADMIN FELHASZNÁLÓ: MÓDOSÍTÁS GOMB -->
    <div style="text-align: center; margin-top: 10px;">
    <a href="admin_termekek.php?id=<?= $sor['id'] ?>" class="bejelentkezes-link">Módosítás</a>
</div>

<?php else: ?>
    <!-- NEM BEJELENTKEZETT LÁTOGATÓ -->
    <p>
        <em style="color: #5c3a2e;">Rendeléshez </em>
        <a class="bejelentkezes-link" href="javascript:void(0)" onclick="megnyitLoginModalt()">Jelentkezz be!</a>
    </p>
<?php endif; ?>
</div>
<?php endwhile; ?>
</main>

<!-- -------- REGISZTRÁCIÓS MODÁL -------- -->
<div class="modal" id="regModal">
    <div class="modal-content">
        <!-- Bezáró X gomb -->
        <span class="modal-close" onclick="zarModalt()">×</span>
        <div class="modal-flex">
            <!-- Dinamikusan betöltött regisztrációs form -->
            <div id="regisztracioTartalom">Betöltés...</div>
            <!-- Oldalsó nagy logó -->
            <div class="modal-logo-big">Fabolcs</div>
        </div>
    </div>
</div>

<!-- -------- BEJELENTKEZÉS MODÁL -------- -->
<div class="modal" id="loginModal">
    <div class="modal-content">
        <!-- Bezáró X gomb -->
        <span class="modal-close" onclick="zarLoginModalt()">×</span>
        <div class="modal-flex">
            <!-- Dinamikusan betöltött bejelentkezés form -->
            <div id="bejelentkezesTartalom">Betöltés...</div>
            <!-- Oldalsó nagy logó -->
            <div class="modal-logo-big">Fabolcs</div>
        </div>
    </div>
</div>

<!-- -------- JAVASCRIPT FUNKCIÓK -------- -->
<script>
/* Menü mobilon nyit/zár funkció (ha lenne hozzá authLinks) */
function toggleMenu() {
    const menu = document.getElementById("authLinks");
    menu.classList.toggle("active");
}

/* MENNYISÉG NÖVELÉSE A TERMÉKLAP KOSÁRBA GOMB MELLETT */
function novel(id) {
    let mezo = document.getElementById('mennyiseg_' + id);
    mezo.value = parseInt(mezo.value) + 1;
}

/* MENNYISÉG CSÖKKENTÉSE A TERMÉKLAP KOSÁRBA GOMB MELLETT */
function csokkent(id) {
    let mezo = document.getElementById('mennyiseg_' + id);
    let aktualis = parseInt(mezo.value);
    if (aktualis > 1) {
        mezo.value = aktualis - 1;
    }
}


/**
 * Regisztrációs modál megnyitása és űrlap betöltése
 */
function megnyitModalt() {
    // Regisztrációs modal megjelenítése
    document.getElementById('regModal').style.display = 'flex';

    // Betöltjük a regisztráció.php tartalmát AJAX-al
    fetch('regisztracio.php')
        .then(res => res.text())
        .then(html => {
            // Betöltött HTML-t beillesztjük a modal belsejébe
            document.getElementById('regisztracioTartalom').innerHTML = html;

            // Most már létezik a form is, eseményfigyelőt adunk rá
            const form = document.getElementById('regForm');
            form.addEventListener('submit', function(e) {
                e.preventDefault();

                // FormData objektumba csomagoljuk az adatokat
                const adatok = new FormData(form);

                // POST kérés regisztracio.php-nak
                fetch('regisztracio.php', {
                    method: 'POST',
                    body: adatok
                })
                .then(res => res.json())
                .then(valasz => {
                    // Visszajelzés megjelenítése a felhasználónak
                    const kiiras = document.getElementById('regValasz');
                    if (valasz.siker) {
                        kiiras.style.color = 'green';
                        kiiras.innerText = 'Sikeres regisztráció!';
                        // Modal bezárása 2 másodperc múlva
                        setTimeout(() => zarModalt(), 2000);
                    } else {
                        kiiras.style.color = 'red';
                        kiiras.innerText = valasz.hiba;
                    }
                });
            });
        });
}

/**
 * Regisztrációs modál bezárása
 */
function zarModalt() {
    document.getElementById('regModal').style.display = 'none';
    document.getElementById('regisztracioTartalom').innerHTML = '';
}

/**
 * Bejelentkezési modál megnyitása és űrlap betöltése
 */
function megnyitLoginModalt() {
    // Login modal megjelenítése
    document.getElementById('loginModal').style.display = 'flex';

    // Betöltjük a bejelentkezes.php tartalmát AJAX-al
    fetch('bejelentkezes.php')
        .then(res => res.text())
        .then(html => {
            // Betöltött HTML-t beillesztjük
            document.getElementById('bejelentkezesTartalom').innerHTML = html;

            // Most már létezik a form is, eseményfigyelőt adunk rá
            const form = document.getElementById('loginForm');
            form.addEventListener('submit', function(e) {
                e.preventDefault();

                // FormData objektumba csomagoljuk az adatokat
                const adatok = new FormData(form);

                // POST kérés bejelentkezes.php-nak
                fetch('bejelentkezes.php', {
                    method: 'POST',
                    body: adatok
                })
                .then(res => res.json())
                .then(valasz => {
                    // Visszajelzés megjelenítése a felhasználónak
                    const kiiras = document.getElementById('loginValasz');
                    if (valasz.siker) {
                        kiiras.style.color = 'green';
                        kiiras.innerText = 'Sikeres bejelentkezés...';
                        // Oldal újratöltése 1.5 másodperc múlva
                        setTimeout(() => location.reload(), 1500);
                    } else {
                        kiiras.style.color = 'red';
                        kiiras.innerText = valasz.hiba;
                    }
                });
            });
        });
}

/**
 * Bejelentkezési modál bezárása
 */
function zarLoginModalt() {
    document.getElementById('loginModal').style.display = 'none';
    document.getElementById('bejelentkezesTartalom').innerHTML = '';
}
</script>
</body>
</html>