<?php
session_start();  // Session indítása, hogy a felhasználói állapot megmaradjon
require_once 'adatbazis.php';  // Adatbázis kapcsolat betöltése

$uzenet = '';  // Válasz üzenet tárolása
$hiba = '';    // Hibauzenet tárolása

if ($_SERVER["REQUEST_METHOD"] === "POST") {  // Csak POST kérés esetén dolgozunk
    // A formból érkező adatok lekérése és levágása felesleges szóközökről
    $nev = trim($_POST['nev'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $telefon = trim($_POST['telefon'] ?? '');
    $uzenet_szoveg = trim($_POST['uzenet'] ?? '');

    // Validációk, ellenőrzések:
    if ($nev === '' || $email === '' || $telefon === '' || $uzenet_szoveg === '') {
        // Kötelező mezők kitöltésének ellenőrzése
        $hiba = "Minden mező kitöltése kötelező!";
    }
    elseif (!preg_match('/^[a-zA-ZáéíóöőúüűÁÉÍÓÖŐÚÜŰ\s-]{3,}$/u', $nev)) {
        // Név formátum ellenőrzése (csak betűk, szóköz, kötőjel, legalább 3 karakter)
        $hiba = "A név csak betűket, szóközt és kötőjelet tartalmazhat, minimum 3 karakterrel.";
    }
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match('/^[^@]+@[^@]+\.[^@]+$/', $email)) {
        // Email formátum validálása PHP beépített FILTER_VALIDATE_EMAIL és egy regex-szel
        $hiba = "Érvénytelen email cím formátum!";
    }
    elseif (!preg_match('/^[0-9+\s()-]{6,}$/', $telefon)) {
        // Telefonszám formátum ellenőrzése (számok, szóköz, +, kötőjel, zárójel, minimum 6 karakter)
        $hiba = "A telefonszám csak számokat, szóközt, + jelet, zárójelet és kötőjelet tartalmazhat, minimum 6 karakterrel.";
    }
    elseif (!preg_match('/^[a-zA-Z0-9áéíóöőúüűÁÉÍÓÖŐÚÜŰ\s.,!"\'-]{3,}$/u', $uzenet_szoveg)) {
        // Üzenet tartalom validálása (megengedett karakterek és minimum 3 karakter)
        $hiba = "Az üzenet csak betűket, számokat, pontot, vesszőt, felkiáltójelet, idézőjelet, kötőjelet és szóközt tartalmazhat, minimum 3 karakterrel.";
    }
    else {
        // Ha minden rendben, beszúrjuk az üzenetet az adatbázisba
        $stmt = $adatbazis->prepare("INSERT INTO egyedi_keresek (nev, email, telefon, uzenet) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $nev, $email, $telefon, $uzenet_szoveg);

        if ($stmt->execute()) {
            // Sikeres adatbázis mentés esetén visszajelzés
            $uzenet = "Köszönjük! Az üzenetet sikeresen elküldte. Hamarosan felvesszük Önnel a kapcsolatot.";
        } else {
            // Hiba esetén hibaüzenet
            $hiba = "Hiba történt az üzenet mentésekor.";
        }
        $stmt->close();  // Lekérdezés lezárása
    }
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
<meta charset="UTF-8">
<title>Egyedi elképzelés</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
/* Egyedi betűtípus betöltése */
@font-face {
    font-family: 'Distant Stroke';
    src: url('fonts/Distant_Stroke.otf') format('opentype');
    font-weight: normal;
    font-style: normal;
}
/* Alap test és háttér beállítás */
body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
    background-color: #4b2e1e;  /* Sötétbarna háttér */
    position: relative;
    min-height: 100vh;  /* Minimum teljes képernyő magasság */
}
/* Háttérkép fakéreg mintával, fix pozícióban */
body::after {
    content: "";
    position: fixed;
    top: 0; left: 0;
    width: 100%; height: 100%;
    background: url('kepek/erezet2.jpg') repeat;
    z-index: -1;  /* Háttérként a tartalom mögött */
}
/* Nagy logó box kialakítása */
.logo-box {
    background: #5c3a2e;  /* Sötétbarna */
    border-radius: 12px;
    padding: 10px 30px;
    margin: 30px auto 10px;
    max-width: 720px;  /* Maximum szélesség */
    width: 95%;  /* Reszponzív szélesség */
    text-align: center;
    font-family: 'Distant Stroke', sans-serif;  /* Egyedi betűtípus */
    font-size: 80px;
    color: #ffffff;  /* Fehér szöveg */
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);  /* Lágy árnyék */
}
/* Modal doboz stílusa */
.modal-box {
    background: #f5f5dc;  /* Világos bézs háttér */
    border-radius: 12px;
    padding: 30px;
    max-width: 720px;
    width: 95%;
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
    margin: 20px auto;  /* Középre igazítás, fent-alul margó */
}
/* Modal belső címsor stílusa */
.modal-box h2 {
    text-align: center;
    margin-top: 0;
}
/* Modal bekezdések margója és középre igazítása */
.modal-box p {
    margin: 10px 0 20px;
    text-align: center;
}
/* Űrlap flexbox stílusa, függőleges elrendezés, részek közti távolság */
form {
    display: flex;
    flex-direction: column;
    gap: 15px;
}
/* Label stílusa: vastag, barna szín */
label {
    font-weight: bold;
    color: #5c3a2e;
}
/* Szöveg-, email- és telefonszám mezők, valamint textarea stílusa */
input[type="text"], input[type="email"], input[type="tel"], textarea {
    padding: 10px;                   /* Belső margó a kényelmes gépeléshez */
    border-radius: 5px;             /* Lekerekített sarkok */
    border: 1px solid #ccc;         /* Szürke keret */
    width: 100%;                   /* Teljes szélesség az űrlap konténerben */
    box-sizing: border-box;        /* Padding is beleszámít a szélességbe */
}

/* Többsoros szövegmező minimum magassága és méretváltoztatás iránya */
textarea {
    min-height: 120px;             /* Minimum 120 pixel magasság */
    resize: vertical;              /* Csak függőlegesen állítható méret */
}

/* Gombokat és vissza linkeket tartalmazó konténer stílusa */
.gomb-container {
    display: flex;
    flex-direction: column;        /* Függőleges elrendezés */
    align-items: center;           /* Középre igazítás */
    gap: 10px;                    /* Elemei között 10px hézag */
    margin-top: 20px;             /* Felül távolság */
}

/* Gombok és vissza linkek közös stílusa */
button, .vissza-link {
    padding: 12px 30px;           /* Kényelmes kattinthatóság */
    background-color: #5c3a2e;    /* Sötétbarna háttér */
    color: white;                 /* Fehér szöveg */
    border: none;                 /* Nincs keret */
    border-radius: 5px;           /* Lekerekített sarkok */
    font-weight: bold;            /* Félkövér szöveg */
    cursor: pointer;              /* Kéz kurzor */
    text-decoration: none;        /* Link aláhúzás kikapcsolva */
    text-align: center;           /* Szöveg középre */
    display: inline-block;        /* Inline blokk elemek */
    width: 80%;                   /* 80% szélesség a konténerből */
    max-width: 300px;             /* Maximum 300px szélesség */
}

/* Gombok és vissza linkek hover effektje */
button:hover, .vissza-link:hover {
    background-color: #3e251b;    /* Sötétebb barna hoverkor */
}

/* Sikeres művelet visszajelzésének stílusa */
.success-message {
    color: green;
    text-align: center;
    margin-top: 10px;
}

/* Hibás művelet visszajelzésének stílusa */
.error-message {
    color: red;
    text-align: center;
    margin-top: 10px;
}
</style>
<head>
<div class="logo-box">Fabolcs</div>
<div class="modal-box">
    <!-- Címsor -->
    <h2>Egyedi elképzelés</h2>
    <!-- Információs szöveg a felhasználónak -->
    <p>Kedves látogató! Egyedi elképzelését az alábbi űrlap kitöltésével tudja számomra elküldeni. Az Ön által megadott e-mail címre pedig küldeni fogok egy látványtervet.</p>

    <!-- Sikeres üzenet visszajelzés -->
    <?php if ($uzenet): ?>
        <div class="success-message"><?= htmlspecialchars($uzenet) ?></div>
    <!-- Hibaüzenet visszajelzés -->
    <?php elseif ($hiba): ?>
        <div class="error-message"><?= htmlspecialchars($hiba) ?></div>
    <?php endif; ?>

    <!-- Űrlap az egyedi elképzelés beküldésére -->
    <form method="post" action="">
        <!-- Név mező -->
        <label for="nev">Név:<br>
            <input type="text" id="nev" name="nev" required placeholder="Kötelező a kitöltése...">
        </label>

        <!-- Email mező -->
        <label for="email">Email cím:<br>
            <input type="email" id="email" name="email" required placeholder="Kötelező a kitöltése...">
        </label>

        <!-- Telefonszám mező -->
        <label for="telefon">Telefonszám:<br>
            <input type="tel" id="telefon" name="telefon" required placeholder="Kötelező a kitöltése...">
        </label>

        <!-- Üzenet (szövegmező) -->
        <label for="uzenet">Üzenet / Egyedi elképzelés részletei:<br>
            <textarea id="uzenet" name="uzenet" required placeholder="Írd le részletesen az elképzelésed..."></textarea>
        </label>

        <!-- Gombok tartalmazó div -->
        <div class="gomb-container">
            <!-- Küldés gomb -->
            <button type="submit">Küldés</button>
            <!-- Vissza a főoldalra link -->
            <a href="index.php" class="vissza-link">← Vissza a főoldalra</a>
        </div>
    </form>
</div>
</body>
</html>
