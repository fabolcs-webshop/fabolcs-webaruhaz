<?php
// Session indítása, hogy elérjük a felhasználói adatokat
session_start();

// Adatbázis kapcsolat betöltése
require_once 'adatbazis.php';

// Ellenőrizzük, hogy be van-e jelentkezve a felhasználó
if (!isset($_SESSION['felhasznalo_id'])) {
    // Ha nincs, átirányítás a bejelentkezéshez
    header("Location: bejelentkezes.php");
    exit();
}

// Felhasználó ID lekérése a sessionből
$felhasznalo_id = $_SESSION['felhasznalo_id'];

// Lekérdezzük, hogy admin jogosultsággal rendelkezik-e
$admin_stmt = $adatbazis->prepare("SELECT admin FROM felhasznalok WHERE id = ?");
$admin_stmt->bind_param("i", $felhasznalo_id);
$admin_stmt->execute();
$admin_stmt->bind_result($admin);
$admin_stmt->fetch();
$admin_stmt->close();

// Ha nem admin, megjelenítünk egy jogosultság hiányát jelző üzenetet és kilépünk
if (!$admin) {
    echo "Nincs jogosultságod az oldal eléréséhez.";
    exit();
}

// Termék törlésének kezelése POST kérésből
if (isset($_POST['torles_id'])) {
    $id = (int)$_POST['torles_id'];

    // Először lekérjük a törlendő termékhez tartozó képfájlt
    $stmt = $adatbazis->prepare("SELECT kep FROM termekek WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($kep);
    $stmt->fetch();
    $stmt->close();

    // Ha a kép létezik és elérhető a fájlrendszerben, akkor töröljük is
    if ($kep && file_exists($kep)) {
        unlink($kep);
    }

    // Ezután töröljük a terméket az adatbázisból
    $stmt = $adatbazis->prepare("DELETE FROM termekek WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();

    // Visszairányítás az admin terméklistára, hogy frissüljön az oldal
    header("Location: admin_termekek.php?deleted=1");
    exit();
}

// Termék módosítás kezelése POST kérésből
if (isset($_POST['modosit_id'])) {
    $id = (int)$_POST['modosit_id'];
    $nev = trim($_POST['nev']);         // Termék neve
    $leiras = trim($_POST['leiras']);   // Termék leírása
    $ar = (int)$_POST['ar'];            // Termék ára
    $celutvonal = $_POST['regi_kep'] ?? ''; // Régi kép elérési útja alapértelmezettként

    // Ha van új kép feltöltve, akkor a fájlt áthelyezzük a megfelelő mappába
    if (isset($_FILES['uj_kep']) && $_FILES['uj_kep']['error'] === UPLOAD_ERR_OK) {
        $fajlnev = basename($_FILES['uj_kep']['name']);
        $celutvonal = "kepek/" . $fajlnev;
        move_uploaded_file($_FILES['uj_kep']['tmp_name'], $celutvonal);
    }

    // Frissítjük az adatokat az adatbázisban
    $stmt = $adatbazis->prepare("UPDATE termekek SET nev = ?, leiras = ?, ar = ?, kep = ? WHERE id = ?");
    $stmt->bind_param("ssisi", $nev, $leiras, $ar, $celutvonal, $id);
    $stmt->execute();
    $stmt->close();

    // Visszairányítás az admin terméklistára, hogy lássuk a változtatásokat
    header("Location: admin_termekek.php?updated=1");
    exit();
}

// Keresési funkció kezelése GET paraméter alapján
$kereses = $_GET['kereses'] ?? '';
if ($kereses) {
    // Ha van keresési kifejezés, akkor LIKE keresést végzünk az adatbázisban a termék nevekre
    $stmt = $adatbazis->prepare("SELECT * FROM termekek WHERE nev LIKE ? ORDER BY id DESC");
    $like = "%$kereses%";
    $stmt->bind_param("s", $like);
    $stmt->execute();
    $termekek = $stmt->get_result();
    $stmt->close();
} else {
    // Ha nincs keresési kifejezés, akkor az összes terméket lekérjük, legújabbak elöl
    $termekek = $adatbazis->query("SELECT * FROM termekek ORDER BY id DESC");
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
<meta charset="UTF-8">
<title>Termékek listája</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>
/* Egyedi betűtípus betöltése */
@font-face {
    font-family: 'Distant Stroke';
    src: url('fonts/Distant_Stroke.otf') format('opentype');
    font-weight: normal;
    font-style: normal;
}

/* Alap body stílusok */
body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
    display: flex;
    flex-direction: column;  /* Vertikális elrendezés */
    align-items: center;     /* Középre igazítás vízszintesen */
    background-color: #4b2e1e; /* Sötétbarna háttér */
    position: relative;
    min-height: 100vh;       /* Minimum magasság a teljes képernyő */
}

/* Háttérképet helyez a body mögé, fix pozícióval */
body::after {
    content: "";
    position: fixed;
    top: 0; left: 0;
    width: 100%; height: 100%;
    background: url('kepek/erezet2.jpg') repeat; /* Faerezet minta */
    z-index: -1; /* Háttér mögé helyezi */
}

/* Nagy logó stílusa fent a főoldalon */
.logo-box {
    background: #5c3a2e; /* Sötétbarna háttér */
    border-radius: 12px; /* Lekerekített sarkok */
    padding: 10px 30px;
    margin: 30px auto 10px; /* Fent és alul margó, középre */
    max-width: 720px;
    width: 95%; /* Rugalmas szélesség mobilra */
    text-align: center; /* Szöveg középre */
    font-family: 'Distant Stroke', sans-serif; /* Egyedi betűtípus */
    font-size: 80px; /* Nagy méret */
    color: #ffffff; /* Fehér szöveg */
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2); /* Árnyék */
}

/* Navigációs sáv stílusa */
.navigacio {
    display: flex;
    justify-content: center; /* Linkek középre igazítása */
    align-items: center;
    gap: 15px; /* Közti távolság */
    margin: 10px auto 20px;
    flex-wrap: wrap; /* Több sorba törhet mobilon */
}

/* Navigációs linkek és dropdown gombok */
.navigacio a, .dropdown-button {
    padding: 10px 20px; /* Kényelmes méretű kattintható terület */
    background-color: #5c3a2e; /* Sötétbarna háttér */
    color: white;
    text-decoration: none; /* Link aláhúzás kikapcsolása */
    border-radius: 5px; /* Lekerekített sarkok */
    font-weight: bold;
    border: none;
    cursor: pointer;
}

/* Dropdown konténer pozíciózása */
.dropdown {
    position: relative;
    display: inline-block;
}

/* Dropdown menü rejtett alapból */
.dropdown-content {
    display: none; /* Alapból nem látható */
    position: absolute; /* A dropdown gomb alatt jelenik meg */
    background-color: #fff7e6; /* Világos háttér */
    min-width: 200px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1); /* Lágy árnyék */
    z-index: 1; /* A többi elem fölé kerül */
    border-radius: 5px;
    overflow: hidden; /* Ne lógjon ki a tartalom */
}

/* Dropdown menü linkek stílusa */
.dropdown-content a {
    color: #5c3a2e; /* Barna szöveg */
    padding: 10px;
    text-decoration: none;
    display: block;
    font-weight: bold;
}
/* --- Dropdown menü linkek hover állapota --- */
.dropdown-content a:hover {
    background-color: #f0e6d6; /* Világosabb háttérszín, ha fölé viszed az egeret */
}

/* --- Dropdown menü megjelenítése hover esetén --- */
.dropdown:hover .dropdown-content {
    display: block; /* A dropdown menü megjelenik, ha az egér a dropdown terület fölött van */
}

/* --- Modal doboz stílusa --- */
.modal-box {
    background: #f5f5dc; /* Világos bézs háttér */
    border-radius: 12px; /* Lekerekített sarkok */
    padding: 30px;       /* Belső margó */
    max-width: 720px;    /* Max szélesség */
    width: 95%;          /* Rugalmas szélesség mobilon */
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2); /* Lágy árnyék */
}

/* --- Modal cím stílusa --- */
.modal-title {
    font-size: 28px;        /* Cím mérete */
    font-weight: bold;      /* Félkövér */
    text-align: center;     /* Középre igazítva */
    margin-bottom: 20px;    /* Alatta távolság */
}

/* --- Termék blokk stílusa --- */
.termek {
    background: white;      /* Fehér háttér */
    padding: 15px;          /* Belső margó */
    border-radius: 8px;     /* Lekerekített sarkok */
    margin-bottom: 15px;    /* Alatta távolság */
    box-shadow: 0 0 8px rgba(0,0,0,0.05); /* Finom árnyék */
}

/* --- Termék űrlap elrendezése --- */
.termek form {
    display: flex;          /* Flexbox használata */
    flex-wrap: wrap;        /* Sorokba törhet mobilon */
    justify-content: space-between; /* Elemközök kitöltése */
    gap: 20px;              /* Elemközti hézag */
}

/* --- Termék bal és jobb oldali részei --- */
.termek .bal, .termek .jobb {
    flex: 1 1 300px;        /* Minimum 300px szélesség, rugalmas növekedés */
    display: flex;
    flex-direction: column; /* Függőleges elrendezés */
    gap: 10px;              /* Elemközti távolság */
}

/* --- Input mezők stílusa termék űrlapon --- */
.termek input {
    padding: 8px;           /* Belső margó */
    width: 100%;            /* Teljes szélesség a szülőn belül */
    max-width: 300px;       /* Max szélesség */
    border-radius: 5px;     /* Lekerekített sarkok */
    border: 1px solid #ccc; /* Világos szürke keret */
}

/* --- Szövegmező stílusa --- */
.termek textarea {
    padding: 8px;
    width: 300px;           /* Fix szélesség */
    height: 300px;          /* Fix magasság */
    border-radius: 5px;
    border: 1px solid #ccc;
    resize: none;           /* Nem engedi a méretezést */
}

/* --- Termékkép stílusa --- */
.termek img {
    max-width: 100px;       /* Maximum szélesség */
    height: auto;           /* Automatikus magasság megtartva az arányokat */
    display: block;         /* Blokk szintű elem */
}

/* --- Termék űrlap gomb stílusa --- */
.termek button {
    padding: 8px 16px;
    background-color: #5c3a2e;  /* Sötétbarna háttér */
    color: white;               /* Fehér szöveg */
    border: none;
    border-radius: 5px;
    font-weight: bold;
    cursor: pointer;            /* Mutató kurzor */
}

/* --- Oldal görgetési viselkedés --- */
html {
    scroll-behavior: smooth;    /* Simított görgetés */
}
</style>
<!-- LOGÓ FELIRAT -->
<div class="logo-box">Fabolcs</div>

<!-- NAVIGÁCIÓS SÁV -->
<div class="navigacio">
    <!-- Linkek a főoldalra, új termék hozzáadásra és terméklista oldalra -->
    <a href="index.php">Főoldal</a>
    <a href="admin_uj_termek.php">Új termék</a>
    <a href="admin_termekek.php">Termékek</a>

    <!-- Keresési űrlap GET metódussal -->
    <form method="get" style="display: inline-block;">
        <input type="text" name="kereses" placeholder="Keresés terméknév alapján" 
               style="padding: 8px; max-width: 200px; border-radius: 5px; border: 1px solid #ccc;">
        <button type="submit" class="dropdown-button">Keresés</button>
    </form>
</div>

<!-- TERMÉKEK LISTÁJA MODÁL DOBOZBAN -->
<div class="modal-box">
    <div class="modal-title">Feltöltött termékek</div>

    <!-- PHP ciklus az összes lekért termék megjelenítésére -->
    <?php 
    // Előre pozicionáljuk az eredmény mutatót az első elemre (a biztos frissességért)
    $termekek->data_seek(0); 
    
    // Végigmegyünk minden terméken az adatbázisból lekért eredményből
    while ($termek = $termekek->fetch_assoc()): ?>
    
        <div class="termek" id="termek_<?= $termek['id'] ?>">
            <!-- Termék szerkesztő űrlap POST metódussal és fájl feltöltéssel -->
            <form method="post" enctype="multipart/form-data">
                <!-- Rejtett mezők: módosítás azonosító és az aktuális kép elérési útja -->
                <input type="hidden" name="modosit_id" value="<?= $termek['id'] ?>">
                <input type="hidden" name="regi_kep" value="<?= htmlspecialchars($termek['kep']) ?>">

                <!-- Bal oldali rész: név és leírás -->
                <div class="bal">
                    <label>Név:</label>
                    <input type="text" name="nev" value="<?= htmlspecialchars($termek['nev']) ?>">

                    <label>Leírás:</label>
                    <textarea name="leiras"><?= htmlspecialchars($termek['leiras']) ?></textarea>
                </div>

                <!-- Jobb oldali rész: ár, kép és kép feltöltés -->
                <div class="jobb">
                    <label>Ár (Ft):</label>
                    <input type="number" name="ar" value="<?= $termek['ar'] ?>">

                    <!-- Ha van kép és létezik a fájl, megjelenítjük -->
                    <?php if (!empty($termek['kep']) && file_exists($termek['kep'])): ?>
                        <label>Jelenlegi kép:</label>
                        <img src="<?= htmlspecialchars($termek['kep']) ?>" alt="Termékkép">
                    <?php endif; ?>

                    <label>Új kép (ha cserélni szeretnéd):</label>
                    <input type="file" name="uj_kep" accept="image/*">

                    <!-- Módosítás gomb -->
                    <button type="submit">Módosítás</button>
                </div>
            </form>

            <!-- Termék törlésére szolgáló külön űrlap -->
            <form method="post">
                <!-- Rejtett mező a törlendő termék azonosítójával -->
                <input type="hidden" name="torles_id" value="<?= $termek['id'] ?>">
                <!-- Törlés gomb, amely megkérdezi a felhasználót mielőtt töröl -->
                <button type="submit" onclick="return confirm('Biztosan törölni szeretnéd?')">Törlés</button>
            </form>
        </div>
    <?php endwhile; ?>
</div>
</body>
</html>


