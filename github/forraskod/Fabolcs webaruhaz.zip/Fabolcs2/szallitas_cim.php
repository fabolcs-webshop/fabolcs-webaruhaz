<?php
// FEJLESZTÉSI HIBAKIJELZÉS BEKAPCSOLÁSA
// → Hasznos fejlesztés közben, hogy minden PHP hiba/figyelmeztetés ki legyen írva a böngészőre
ini_set('display_errors', 1);
error_reporting(E_ALL);

// SESSION INDÍTÁSA
session_start();
require_once 'adatbazis.php'; // Adatbázis kapcsolat

// Ha be van jelentkezve, megkérdezzük az adatbázistól a kosár tartalmát
$felhasznalo_id = $_SESSION['felhasznalo_id'] ?? null;

if ($felhasznalo_id) {
    // SQL: felhasználó kosarában lévő tételek száma
    $stmt = $adatbazis->prepare("SELECT COUNT(*) FROM kosar_tetelek WHERE felhasznalo_id = ?");
    $stmt->bind_param("i", $felhasznalo_id);
    $stmt->execute();
    $stmt->bind_result($kosar_db);
    $stmt->fetch();
    $stmt->close();

    // Ha üres a kosár → visszadobjuk a főoldalra figyelmeztetéssel
    if ($kosar_db == 0) {
        echo "<script>alert('A kosarad üres!'); window.location.href='home.php';</script>";
        exit();
    }
} 
// Ha nincs bejelentkezve, akkor a SESSION kosarat ellenőrizzük
elseif (empty($_SESSION['kosar'])) {
    echo "<script>alert('A kosarad üres!'); window.location.href='home.php';</script>";
    exit();
}

// HIBÁK és FELVITT ÉRTÉKEK inicializálása
$errors = [];
$values = [
    'nev' => '',
    'irszam' => '',
    'varos' => '',
    'utca' => '',
    'szallitas' => ''
];
$rendeles_megjegyzes = $_SESSION['rendeles_megjegyzes'] ?? '';


// SZÁLLÍTÁSI PARTNEREK LEKÉRÉSE ADATBÁZISBÓL
$partnerek = [];
$result = $adatbazis->query("SELECT id, nev, tipus, ar, kep FROM szallitasi_partnerek");
while ($row = $result->fetch_assoc()) {
    $partnerek[] = $row;
}
$result->free();


// ŰRLAP ELKÜLDÉSEKOR ÉRKEZŐ ADATOK FELDOLGOZÁSA
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Minden mezőt megtisztítunk (trim) és elmentjük
    foreach ($values as $field => $val) {
        $values[$field] = trim($_POST[$field] ?? '');
    }

    // A megjegyzést külön kezeljük és SESSION-ben is tároljuk
    $rendeles_megjegyzes = trim($_POST['rendeles_megjegyzes'] ?? '');
    $_SESSION['rendeles_megjegyzes'] = $rendeles_megjegyzes;


    // VALIDÁCIÓ
    if (!preg_match('/^[a-zA-ZáéíóöőúüűÁÉÍÓÖŐÚÜŰ\s-]{3,}$/u', $values['nev'])) {
        $errors[] = "A teljes név csak betűket, szóközt és kötőjelet tartalmazhat, minimum 3 karakterrel.";
    }

    if (!preg_match('/^\d{4,5}$/', $values['irszam'])) {
        $errors[] = "Az irányítószám 4 vagy 5 számjegyből állhat.";
    }

    if (!preg_match('/^[a-zA-ZáéíóöőúüűÁÉÍÓÖŐÚÜŰ\s-]{2,}$/u', $values['varos'])) {
        $errors[] = "A városnév csak betűket, szóközt és kötőjelet tartalmazhat, minimum 2 karakterrel.";
    }

    if (!preg_match('/^[a-zA-Z0-9áéíóöőúüűÁÉÍÓÖŐÚÜŰ\s,.-]{3,}$/u', $values['utca'])) {
        $errors[] = "Az utca, házszám csak betűket, számokat, szóközt, vesszőt, pontot és kötőjelet tartalmazhat, minimum 3 karakterrel.";
    }

    if (empty($values['szallitas'])) {
        $errors[] = "Válassz szállítási módot!";
    }


    // Ha nincs hiba → tovább a következő lépésre
    if (empty($errors)) {
        $_SESSION['szallitasi_adatok'] = $values;
        header("Location: rendeles_veglegesites.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Szállítási cím megadása</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        /* ------- EGYEDI BETŰTÍPUS ------- */
        @font-face {
    font-family: 'Distant Stroke';
    src: url('fonts/Distant_Stroke.otf') format('opentype');
    font-weight: normal;
    font-style: normal;
}

        /* ------- ALAP BODY STÍLUS ------- */
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            background-color: #4b2e1e;       /* Sötétbarna háttérszín */
            position: relative;
            min-height: 100vh;                /* Legalább képernyőmagasságú háttér */
        }

        /* ------- HÁTTÉRMINTA FAEREZET ------- */
        body::after {
            content: "";
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('kepek/erezet2.jpg') repeat;  /* Ismétlődő faerezet háttér */
            z-index: -1;                                  /* Hátra kerül a tartalom mögé */
        }

        /* ------- FEJLÉC LOGO BOX ------- */
        .logo-box {
            background: #5c3a2e;                  /* Sötétbarna háttér */
            border-radius: 12px;                  /* Lekerekített sarkok */
            padding: 10px 30px;
            margin: 30px auto 10px;               /* Felül/alul margó */
            max-width: 700px;                     /* Maximális szélesség */
            width: 90%;                           /* Mobilbarát rugalmas szélesség */
            text-align: center;
            font-family: 'Distant Stroke', sans-serif;
            font-size: 80px;                      /* Nagy logó felirat */
            color: #ffffff;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2); /* Finom árnyék a doboz alatt */
        }

        /* ------- KÖZPONTI MODAL-BOX STÍLUS ------- */
        .modal-box {
            background: #f5f5dc;                  /* Világos bézs háttérszín */
            border-radius: 12px;
            padding: 30px;
            max-width: 700px;                     /* Nagy képernyőn limitálva */
            width: 90%;                           /* Mobilon is jól néz ki */
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2); /* Árnyék a doboz alatt */
        }

        /* ------- CÍMEK KÖZÉPRE IGAZÍTVA ------- */
        h2 {
            text-align: center;
            margin-top: 0;
        }

        /* ------- HIBAÜZENET DOBOZ STÍLUS ------- */
        .error {
            background: #f8d7da;          /* Világos piros háttér (bootstrap stílus alapján) */
            color: #721c24;               /* Sötétvörös szöveg */
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;          /* Térköz alul, hogy ne ragadjon össze az űrlappal */
        }
        form {
    display: flex;
    flex-direction: column;
    gap: 15px; /* Az űrlap mezői közti távolság */
}

/* ----------- SZÖVEGES INPUT MEZŐK ----------- */
input[type="text"] {
    padding: 10px;                   /* Kényelmes belső margó */
    border-radius: 5px;              /* Lekerekített sarkok */
    border: 1px solid #ccc;          /* Finom szürke keret */
    width: 100%;                     /* Teljes szélesség a konténerben */
}

/* ----------- SZÁLLÍTÁSI PARTNER KÁRTYA ----------- */
.szallitasi-partner {
    display: flex;                   /* Vízszintes elrendezés */
    align-items: center;             /* Képek és szövegek függőlegesen középre */
    gap: 10px;                       /* Hézag az elemek között */
    margin-bottom: 10px;             /* Elválasztás az alatta lévőtől */
    padding: 10px;                   /* Belső margó */
    border: 1px solid #ccc;          /* Finom szürke keret */
    border-radius: 8px;              /* Lekerekített sarkok */
    background-color: #f8f8f8;       /* Világos szürke háttér kiemeléshez */
}

/* ----------- PARTNER LOGÓK KÉPEI ----------- */
.szallitasi-partner img {
    width: 50px;                     /* Kép szélessége fix 50px */
    height: auto;                    /* Magasság automatikusan arányos marad */
}

/* ----------- ALULI NAVIGÁCIÓS GOMBOK KONTAINER ----------- */
.nav-gombok {
    display: flex;                   /* Flexbox soros elrendezés */
    justify-content: center;         /* Középre igazítás */
    gap: 10px;                       /* Hézag a gombok között */
    margin-top: 20px;                /* Felülről elválasztás */
    flex-wrap: wrap;                 /* Mobilbarát, törhető több sorba */
}

/* ----------- NAVIGÁCIÓS GOMBOK STÍLUS ----------- */
.nav-gombok a,
.nav-gombok button {
    padding: 10px 20px;              /* Kényelmes kattinthatóság */
    background-color: #5c3a2e;       /* Barna háttérszín */
    color: white;                    /* Fehér szöveg */
    text-decoration: none;           /* Link aláhúzás kikapcsolva */
    border-radius: 5px;              /* Lekerekített sarkok */
    border: none;                    /* Keret nélküli */
    font-weight: bold;
    cursor: pointer;                 /* Kéz kurzor hoverkor */
}
    </style>
</head>
<body>
<!-- ----------- OLDAL FEJLÉC / LOGÓ ----------- -->
<div class="logo-box">Fabolcs</div>

<!-- ----------- MODÁL DOBOZ - KÖZÉPSŐ TARTALOM ----------- -->
<div class="modal-box">
    <h2>Szállítási cím megadása</h2>

    <!-- ----------- HIBÁK KIJELZÉSE ----------- -->
    <?php if (!empty($errors)): ?>
        <div class="error">
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?= htmlspecialchars($error) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- ----------- ŰRLAP A SZÁLLÍTÁSI CÍMHEZ ÉS SZÁLLÍTÁSI MÓD VÁLASZTÁSÁHOZ ----------- -->
    <form action="rendeles_veglegesites.php" method="post">
        <!-- Teljes név -->
        <input type="text" name="nev" placeholder="Teljes név" value="<?= htmlspecialchars($values['nev']) ?>" required>
        
        <!-- Irányítószám -->
        <input type="text" name="irszam" placeholder="Irányítószám" value="<?= htmlspecialchars($values['irszam']) ?>" required>
        
        <!-- Város -->
        <input type="text" name="varos" placeholder="Város" value="<?= htmlspecialchars($values['varos']) ?>" required>
        
        <!-- Utca, házszám -->
        <input type="text" name="utca" placeholder="Utca, házszám" value="<?= htmlspecialchars($values['utca']) ?>" required>

        <!-- ----------- SZÁLLÍTÁSI PARTNER VÁLASZTÓ RÉSZ ----------- -->
        <h3>Szállítási mód választása:</h3>
        <?php foreach ($partnerek as $partner): ?>
            <label class="szallitasi-partner">
                <!-- Rádiógomb a kiválasztáshoz -->
                <input type="radio" name="szallitas" value="<?= $partner['id'] ?>" required <?= $values['szallitas'] == $partner['id'] ? 'checked' : '' ?>>
                
                <!-- Partner logója -->
                <img src="<?= htmlspecialchars($partner['kep']) ?>" alt="<?= htmlspecialchars($partner['nev']) ?>">
                
                <!-- Partner neve, típusa, ára -->
                <div>
                    <strong><?= htmlspecialchars($partner['nev']) ?></strong><br>
                    <?= htmlspecialchars($partner['tipus']) ?><br>
                    Ár: <?= htmlspecialchars($partner['ar']) ?> Ft
                </div>
            </label>
        <?php endforeach; ?>

        <!-- ----------- MEGJEGYZÉS MEZŐ ----------- -->
        <h3>Megjegyzés a rendeléshez:</h3>
        <textarea name="rendeles_megjegyzes" rows="4" style="width: 100%; border-radius: 5px; padding: 8px; border: 1px solid #ccc;">
            <?= htmlspecialchars($rendeles_megjegyzes) ?>
        </textarea>

        <!-- ----------- NAVIGÁCIÓS GOMBOK ALUL ----------- -->
        <div class="nav-gombok">
            <!-- Vissza gomb a kosárhoz -->
            <a href="kosar.php" class="vissza">&larr; Vissza a kosárhoz</a>
            
            <!-- Tovább gomb a véglegesítéshez -->
            <button type="submit" class="tovabb">Tovább a véglegesítéshez &rarr;</button>
        </div>
    </form>
</div>
</body>
</html>