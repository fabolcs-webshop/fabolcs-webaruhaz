<?php
session_start();
require_once 'adatbazis.php';

header('Content-Type: application/json');

$bejelentkezett = isset($_SESSION['felhasznalo_id']);
$felhasznalo_id = $_SESSION['felhasznalo_id'] ?? null;

$termek_id = (int)($_POST['termek_id'] ?? 0);
$mennyiseg = max(0, (int)($_POST['mennyiseg'] ?? 0));
$reszosszeg = 0;

// Mindig próbáljuk lekérni a termék árát először!
$stmt = $adatbazis->prepare("SELECT ar FROM termekek WHERE id = ?");
$stmt->bind_param("i", $termek_id);
$stmt->execute();
$stmt->bind_result($ar);
if ($stmt->fetch()) {
    $reszosszeg = $ar * $mennyiseg;
}
$stmt->close();

// Ezután frissítjük az adatokat (vagy töröljük)
if ($termek_id > 0) {
    if ($bejelentkezett) {
        if ($mennyiseg > 0) {
            // Ellenőrizzük, hogy van-e már ilyen tétel
            $ellenor = $adatbazis->prepare("SELECT id FROM kosar_tetelek WHERE felhasznalo_id = ? AND termek_id = ?");
            $ellenor->bind_param("ii", $felhasznalo_id, $termek_id);
            $ellenor->execute();
            $eredmeny = $ellenor->get_result();

            if ($eredmeny->num_rows > 0) {
                // Létezik → frissítjük
                $stmt = $adatbazis->prepare("UPDATE kosar_tetelek SET mennyiseg = ? WHERE felhasznalo_id = ? AND termek_id = ?");
                $stmt->bind_param("iii", $mennyiseg, $felhasznalo_id, $termek_id);
            } else {
                // Nem létezik → beszúrjuk
                $stmt = $adatbazis->prepare("INSERT INTO kosar_tetelek (felhasznalo_id, termek_id, mennyiseg) VALUES (?, ?, ?)");
                $stmt->bind_param("iii", $felhasznalo_id, $termek_id, $mennyiseg);
            }

            $stmt->execute();
            $stmt->close();
            $ellenor->close();
        } else {
            // 0 mennyiség → törlés
            $stmt = $adatbazis->prepare("DELETE FROM kosar_tetelek WHERE felhasznalo_id = ? AND termek_id = ?");
            $stmt->bind_param("ii", $felhasznalo_id, $termek_id);
            $stmt->execute();
            $stmt->close();
        }
    } else {
        // Vendég kosár
        if ($mennyiseg > 0) {
            $_SESSION['kosar'][$termek_id] = $mennyiseg;
        } else {
            unset($_SESSION['kosar'][$termek_id]);
        }
    }
}

echo json_encode([
    'reszosszeg' => $reszosszeg
]);