<?php
// MINDEN oldal elején session indítása
// Ez teszi lehetővé a bejelentkezett állapot követését
session_start();

// Adatbáziskapcsolat betöltése
require_once 'adatbazis.php';

// A kliensnek visszaküldendő válaszobjektum előkészítése
// Alapértelmezett érték: nincs hiba, nem sikeres
$response = ['hiba' => '', 'siker' => false];

// Ha az oldal POST kérésre fut le (azaz elküldték a formot)
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Felhasználó által megadott email és jelszó beolvasása
    $email = trim($_POST['email']);
    $jelszo = trim($_POST['jelszo']);

    // SQL lekérdezés előkészítése:
    // Csak azokat a felhasználókat engedi ellenőrizni, akiknél torolve IS NULL
    // Így egy törölt (inaktivált) fiókkal sem lehet belépni
    $stmt = $adatbazis->prepare(
        "SELECT id, jelszo FROM felhasznalok WHERE email = ? AND torolve IS NULL"
    );
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($id, $hash);

    // Megpróbáljuk lekérni az eredményt
    if ($stmt->fetch()) {
        // Ha van ilyen aktív felhasználó, ellenőrizzük a jelszót
        if (password_verify($jelszo, $hash)) {
            // Helyes jelszó esetén session változók beállítása
            $_SESSION['felhasznalo_id'] = $id;
            $_SESSION['felhasznalo_email'] = $email;
            $response['siker'] = true;
        } else {
            // Hibás jelszó
            $response['hiba'] = 'Hibás jelszó.';
        }
    } else {
        // Nem létező vagy törölt felhasználó
        $response['hiba'] = 'A fiókja törölve lett! Kérem vegye fel a kapcsolatot velünk.';
    }

    // Lekérdezés lezárása
    $stmt->close();

    // JSON válasz visszaküldése
    echo json_encode($response);
    exit;
}
?>

<!-- Ha nem POST, akkor az alábbi HTML űrlap jelenik meg (pl. AJAX betöltéskor) -->
<h2 style="text-align: center;">Bejelentkezés</h2>

<form id="loginForm">
    <label>
        E-mail cím:<br>
        <input type="email" name="email" required>
    </label>
    <br><br>
    <label>
        Jelszó:<br>
        <input type="password" name="jelszo" required>
    </label>
    <br><br>
    <button type="submit">Belépek</button>
    <div id="loginValasz" style="margin-top: 10px; color: red;"></div>
</form>