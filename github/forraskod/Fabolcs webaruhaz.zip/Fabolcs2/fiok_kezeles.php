<?php
session_start();
require_once 'adatbazis.php';

// Ellenőrzés: csak admin láthassa az oldalt
if (!isset($_SESSION['felhasznalo_id'])) {
    header("Location: bejelentkezes.php"); // Ha nincs bejelentkezve, átirányítás bejelentkezéshez
    exit();
}

$felhasznalo_id = $_SESSION['felhasznalo_id'];

// Lekérdezzük, hogy a bejelentkezett felhasználó admin-e
$stmt = $adatbazis->prepare("SELECT admin FROM felhasznalok WHERE id = ?");
$stmt->bind_param("i", $felhasznalo_id);
$stmt->execute();
$stmt->bind_result($is_admin);
$stmt->fetch();
$stmt->close();

// Ha nem admin, akkor nem férhet hozzá az oldalhoz
if (!$is_admin) {
    echo "<h2 style='color: red; text-align:center;'>Nincs jogosultságod ehhez az oldalhoz!</h2>";
    exit();
}

// Ha POST kérés érkezik, akkor kezeljük a törlést vagy aktiválást
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Fiók törlés (soft delete: torolve mezőbe aktuális időpont)
    if (isset($_POST['torles_id'])) {
        $torles_id = (int)$_POST['torles_id'];
        $stmt = $adatbazis->prepare("UPDATE felhasznalok SET torolve = NOW() WHERE id = ?");
        $stmt->bind_param("i", $torles_id);
        $stmt->execute();
        $stmt->close();
        header("Location: fiok_kezeles.php"); // Oldal újratöltése törlés után
        exit();
    }

    // Fiók újraaktiválás (torolve mező NULL-ra állítása)
    if (isset($_POST['aktiv_id'])) {
        $aktiv_id = (int)$_POST['aktiv_id'];
        $stmt = $adatbazis->prepare("UPDATE felhasznalok SET torolve = NULL WHERE id = ?");
        $stmt->bind_param("i", $aktiv_id);
        $stmt->execute();
        $stmt->close();
        header("Location: fiok_kezeles.php"); // Oldal újratöltése aktiválás után
        exit();
    }
}

// Lekérdezzük az összes felhasználót az adatbázisból
$felhasznalok = [];
$result = $adatbazis->query("SELECT id, email, regdatum, torolve FROM felhasznalok ORDER BY id ASC");
while ($sor = $result->fetch_assoc()) {
    $felhasznalok[] = $sor; // Az összes felhasználó adatai bekerülnek egy tömbbe
}
$result->free();
?>
<!DOCTYPE html>
<html lang="hu">
<head>
<meta charset="UTF-8">
<title>Admin - Fiók kezelése</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
@font-face {
    font-family: 'Distant Stroke';
    src: url('fonts/Distant_Stroke.otf') format('opentype');
    font-weight: normal;
    font-style: normal;
}
body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif; /* Alapértelmezett betűtípus */
    background-color: #4b2e1e; /* Sötétbarna háttér */
    position: relative;
    min-height: 100vh; /* Legalább teljes magasság */
}
body::after {
    content: "";
    position: fixed;
    top: 0; left: 0;
    width: 100%; height: 100%;
    background: url('kepek/erezet2.jpg') repeat; /* Fa erezetes háttérkép ismétlődve */
    z-index: -1; /* Háttérbe helyezés */
}
.logo-box {
    background: #5c3a2e; /* Sötétbarna doboz háttér */
    border-radius: 12px; /* Lekerekített sarkok */
    padding: 10px 30px; /* Belső margók */
    margin: 30px auto 10px; /* Külső margók, középre igazítás */
    max-width: 720px;
    width: 95%; /* Rugalmas szélesség */
    text-align: center; /* Szöveg középre */
    font-family: 'Distant Stroke', sans-serif; /* Egyedi betűtípus */
    font-size: 80px; /* Nagy betűméret */
    color: #ffffff; /* Fehér szín */
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2); /* Árnyék */
}
.modal-box {
    background: #f5f5dc; /* Világos bézs háttér */
    border-radius: 12px;
    padding: 30px;
    max-width: 900px;
    width: 95%;
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
    margin: 20px auto; /* Középre igazítás és margó */
}
.modal-box h2 {
    margin-top: 0;
    text-align: center; /* Cím középre */
}

.user-card {
    background: #fff; /* Fehér háttér a kártyán */
    border: 1px solid #5c3a2e; /* Sötétbarna keret */
    border-radius: 10px; /* Lekerekített sarkok */
    padding: 15px; /* Belső margó */
    margin-bottom: 15px; /* Alsó margó kártyák között */
    box-shadow: 0 4px 10px rgba(0,0,0,0.1); /* Finom árnyék */
    display: flex; /* Flexbox elrendezés */
    flex-direction: column; /* Függőleges elemek egymás alatt */
    gap: 8px; /* Hézag az elemek között */
}

.user-card p {
    margin: 4px 0; /* Függőleges margó */
    font-size: 15px; /* Betűméret */
}

.user-card form {
    margin: 0; /* Form elemek marginja nincs */
}

.user-card button {
    padding: 8px 16px; /* Belső margó gombon */
    background-color: #5c3a2e; /* Barna háttér */
    color: white; /* Fehér szöveg */
    border: none; /* Keret nélkül */
    border-radius: 5px; /* Lekerekített sarkok */
    cursor: pointer; /* Mutató kurzor */
    font-weight: bold; /* Félkövér */
    margin-top: 8px; /* Fent távolság */
}

.user-card button:hover {
    background-color: #3e251b; /* Sötétebb barna hoverkor */
}

.vissza-link {
    display: inline-block; /* Blokk elemként viselkedik, de sorban marad */
    margin-top: 20px; /* Fent távolság */
    padding: 10px 20px; /* Belső margó */
    background-color: #5c3a2e; /* Barna háttér */
    color: white; /* Fehér szöveg */
    text-decoration: none; /* Aláhúzás eltávolítása */
    border-radius: 5px; /* Lekerekített sarkok */
    font-weight: bold; /* Félkövér */
    text-align: center; /* Középre igazítás */
}
.vissza-link:hover {
    background-color: #3e251b; /* Sötétebb barna hoverkor */
}

/* Nagyobb képernyőkre (minimum 700px szélesség) */
@media (min-width: 700px) {
    .user-card {
        flex-direction: row; /* Elemei vízszintesen helyezkednek el */
        justify-content: space-between; /* Közöttük hely kitöltése */
        align-items: center; /* Vertikális középre igazítás */
    }
    .user-card p {
        font-size: 16px; /* Kicsit nagyobb betűméret */
    }
}
</style>
</head>
<body>
<div class="logo-box">Fabolcs</div> <!-- Nagy, egyedi stílusú fejléc felirat -->

<div class="modal-box"> <!-- Fehér háttér, lekerekített sarkú tartalomdoboz -->

    <h2>Felhasználói fiókok kezelése</h2> <!-- Oldalcím -->

    <?php if (empty($felhasznalok)): ?>
        <!-- Ha nincs egyetlen regisztrált felhasználó sem -->
        <p>Nincs regisztrált felhasználó.</p>
    <?php else: ?>
        <!-- Felhasználók listázása -->
        <?php foreach ($felhasznalok as $user): ?>
            <div class="user-card"> <!-- Felhasználói kártya konténer -->
                <div>
                    <!-- Felhasználó azonosítója -->
                    <p><strong>ID:</strong> <?= htmlspecialchars($user['id']) ?></p>
                    <!-- Felhasználó email címe -->
                    <p><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
                    <!-- Regisztráció dátuma -->
                    <p><strong>Regisztráció dátuma:</strong> <?= htmlspecialchars($user['regdatum']) ?></p>
                    <!-- Aktuális állapot, törölt vagy aktív -->
                    <p><strong>Állapot:</strong> <?= $user['torolve'] ? 'Törölve (' . htmlspecialchars($user['torolve']) . ')' : 'Aktív' ?></p>
                </div>
                <div>
                    <!-- Ha nem törölt fiók, megjelenik a törlés gomb -->
                    <?php if (!$user['torolve']): ?>
                        <form method="post">
                            <input type="hidden" name="torles_id" value="<?= $user['id'] ?>"> <!-- Törlendő felhasználó ID-ja -->
                            <button type="submit">Fiók törlése</button>
                        </form>
                    <!-- Ha törölt fiókról van szó, megjelenik az újraaktiválás gomb -->
                    <?php else: ?>
                        <form method="post">
                            <input type="hidden" name="aktiv_id" value="<?= $user['id'] ?>"> <!-- Újraaktiválandó felhasználó ID-ja -->
                            <button type="submit">Újraaktiválás</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <!-- Vissza link a főoldalra -->
    <a href="index.php" class="vissza-link">← Vissza főoldalra</a>
</div>
</body>
</html>