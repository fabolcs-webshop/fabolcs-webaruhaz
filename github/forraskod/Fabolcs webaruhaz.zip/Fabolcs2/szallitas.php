<?php
session_start();
?>
<!DOCTYPE html>
<html lang="hu">
<head>
<meta charset="UTF-8">
<title>Szállítási partnerek</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
@font-face {
    font-family: 'Distant Stroke';
    src: url('fonts/Distant_Stroke.otf') format('opentype');
    font-weight: normal;
    font-style: normal;
}
/* Alapértelmezett body stílusok */
body {
    margin: 0; padding: 0;
    font-family: Arial, sans-serif;
    background-color: #4b2e1e; /* Sötétbarna háttér */
    position: relative;
    min-height: 100vh; /* Legalább a teljes képernyő magasság */
}
/* Háttérkép, ami fixen a háttérben marad */
body::after {
    content: "";
    position: fixed; top: 0; left: 0;
    width: 100%; height: 100%;
    background: url('kepek/erezet2.jpg') repeat; /* Faerezet minta */
    z-index: -1; /* A tartalom mögött legyen */
}
/* Logó stílus */
.logo-box {
    background: #5c3a2e; /* Barna háttér */
    border-radius: 12px;
    padding: 10px 30px;
    margin: 30px auto 20px; /* Középre, felül 30px, alul 20px margó */
    max-width: 720px;
    width: 95%; /* Rugalmas szélesség */
    text-align: center;
    font-family: 'Distant Stroke', sans-serif;
    font-size: 80px;
    color: #fff; /* Fehér szöveg */
    box-shadow: 0 8px 30px rgba(0,0,0,0.2); /* Árnyék a logó alatt */
}
/* Modal box stílus */
.modal-box {
    background: #f5f5dc; /* Bézs háttér */
    border-radius: 12px;
    padding: 30px;
    max-width: 720px;
    width: 95%;
    box-shadow: 0 8px 30px rgba(0,0,0,0.2);
    margin: 20px auto 40px; /* Középre, alsó margóval */
    text-align: center;
}
/* Egy szállítási partner dobozának margója */
.szallitas-partner {
    margin-bottom: 30px;
}
/* Szállítási partner kép stílus */
.szallitas-partner img {
    max-width: 150px;
    border-radius: 8px; /* Lekerekített sarkok */
    box-shadow: 0 4px 12px rgba(0,0,0,0.15); /* Finom árnyék */
}
/* Szállítási partner neve (cím) */
.szallitas-partner h3 {
    margin: 10px 0 5px;
    color: #5c3a2e; /* Barna szín */
}
/* Szállítási partner leírása, ára */
.szallitas-partner p {
    margin: 0;
    font-weight: bold;
    color: #3e251b; /* Sötétebb barna szín */
}
.vissza-link {
    display: inline-block; /* Link blokk szintű megjelenítése */
    padding: 12px 30px; /* Belső margó a kattinthatóság növeléséhez */
    background-color: #5c3a2e; /* Sötétbarna háttér */
    color: white; /* Fehér szöveg */
    border-radius: 5px; /* Lekerekített sarkok */
    font-weight: bold; /* Félkövér betű */
    text-decoration: none; /* Aláhúzás eltávolítása */
    cursor: pointer; /* Egérmutató kéz */
}
.vissza-link:hover {
    background-color: #3e251b; /* Sötétebb barna háttér hoverkor */
}
</style>
</head>
<body>
<div class="logo-box">Fabolcs</div>

<div class="modal-box">
    <h2>Szállítási partnerek</h2>

    <div class="szallitas-partner">
        <img src="kepek/foxpost.jpg" alt="FOXPOST">
        <h3>FOXPOST</h3>
        <p>Házhoz szállítás előre fizetéssel</p>
        <p>Ár: 1500 Ft</p>
    </div>

    <div class="szallitas-partner">
        <img src="kepek/gls.jpg" alt="GLS">
        <h3>GLS</h3>
        <p>Házhoz szállítás előre fizetéssel</p>
        <p>Ár: 2000 Ft</p>
    </div>

    <div class="szallitas-partner">
        <img src="kepek/mpl.jpg" alt="MPL">
        <h3>MPL</h3>
        <p>Házhoz szállítás előre fizetéssel</p>
        <p>Ár: 5000 Ft</p>
    </div>

    <a href="index.php" class="vissza-link">← Vissza a főoldalra</a>
</div>
</body>
</html>