<?php
// Session indítása a felhasználói állapot követésére (bejelentkezés, jogosultság)
session_start();

// Adatbázis kapcsolat betöltése
require_once 'adatbazis.php';

// --- Jogosultság ellenőrzése ---
// Csak bejelentkezett admin felhasználók férhetnek hozzá ehhez az oldalhoz
if (!isset($_SESSION['felhasznalo_id'])) {
    // Ha nincs bejelentkezve, átirányítás a bejelentkezési oldalra
    header("Location: bejelentkezes.php");
    exit();
}

// Bejelentkezett felhasználó azonosítója
$felhasznalo_id = $_SESSION['felhasznalo_id'];

// Admin státusz lekérdezése az adatbázisból a felhasználó ID alapján
$stmt = $adatbazis->prepare("SELECT admin FROM felhasznalok WHERE id = ?");
$stmt->bind_param("i", $felhasznalo_id);
$stmt->execute();
$stmt->bind_result($is_admin);
$stmt->fetch();
$stmt->close();

// Ha nem admin, megjelenítünk egy piros szöveget és leállítjuk a scriptet
if (!$is_admin) {
    echo "<h2 style='color: red; text-align:center;'>Nincs jogosultságod ehhez az oldalhoz!</h2>";
    exit();
}

// --- Üzenetek olvasottá tétele ---
// Amikor az oldal betöltődik, az összes olvasatlan üzenetet olvasottnak állítjuk be
$adatbazis->query("UPDATE egyedi_keresek SET olvasott = 1 WHERE olvasott = 0");

// --- Üzenetek frissítése: válaszolt státusz kezelése ---
// Ha a POST kérés tartalmazza a 'valaszolt_ids' tömböt (checkboxok jelölései),
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['valaszolt_ids'])) {
    // Végigiterálunk a kijelölt üzenetek azonosítóin
    $valaszolt_ids = $_POST['valaszolt_ids'];
    foreach ($valaszolt_ids as $id) {
        $id = intval($id); // Biztonsági okokból számra alakítás
        // Frissítjük az adatbázisban az adott üzenetet válaszolt státuszra (1)
        $adatbazis->query("UPDATE egyedi_keresek SET valaszolt = 1 WHERE id = $id");
    }
    // Mivel frissítettünk, újratöltjük az oldalt, hogy a változások megjelenjenek
    header("Location: uzenetek.php");
    exit();
}

// --- Üzenetek lekérése ---
// Lekérdezzük az összes üzenetet az adatbázisból időrend szerint csökkenő sorrendben
$uzenetek = [];
$result = $adatbazis->query("SELECT id, nev, email, telefon, uzenet, datum, olvasott, valaszolt FROM egyedi_keresek ORDER BY datum DESC");

// A lekérdezés eredményét egy tömbbe töltjük, hogy később megjeleníthessük az üzeneteket
while ($row = $result->fetch_assoc()) {
    $uzenetek[] = $row;
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
<meta charset="UTF-8">
<title>Admin - Üzenetek kezelése</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>
/* Egyedi betűtípus betöltése */
@font-face {
    font-family: 'Distant Stroke';
    src: url('fonts/Distant_Stroke.otf') format('opentype');
    font-weight: normal;
    font-style: normal;
}

/* Alapértelmezett body stílus */
body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif; /* Alapértelmezett betűtípus */
    background-color: #4b2e1e; /* Sötétbarna háttér */
    position: relative;
    min-height: 100vh; /* Minimum magasság: a teljes képernyő */
}

/* Háttér kép és stílus */
body::after {
    content: "";
    position: fixed;
    top: 0; left: 0;
    width: 100%; height: 100%;
    background: url('kepek/erezet2.jpg') repeat; /* Faerezetes háttér ismétlődik */
    z-index: -1; /* Háttérként a tartalom mögött */
}

/* Logó doboz stílusa */
.logo-box {
    background: #5c3a2e; /* Sötétbarna háttér */
    border-radius: 12px; /* Lekerekített sarkok */
    padding: 10px 30px; /* Belső margó */
    margin: 30px auto 10px; /* Középre igazítás, felső és alsó margó */
    max-width: 720px; /* Maximum szélesség */
    width: 95%; /* Rugalmas szélesség */
    text-align: center; /* Középre igazított szöveg */
    font-family: 'Distant Stroke', sans-serif; /* Egyedi betűtípus */
    font-size: 80px; /* Nagy méret */
    color: #ffffff; /* Fehér szöveg */
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2); /* Árnyék */
}

/* Modal tartalom dobozának stílusa */
.modal-box {
    background: #f5f5dc; /* Világos bézs háttér */
    border-radius: 12px; /* Lekerekített sarkok */
    padding: 30px; /* Belső margó */
    max-width: 900px; /* Maximum szélesség */
    width: 95%; /* Rugalmas szélesség */
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2); /* Árnyék */
    margin: 20px auto; /* Középre igazítás, függőleges margó */
}

/* Modal fejléc címe */
.modal-box h2 {
    margin-top: 0; /* Nincs felső margó */
    text-align: center; /* Középre igazítás */
}

/* Táblázat stílus */
table {
    width: 100%; /* Teljes szélesség */
    border-collapse: collapse; /* Szegélyek összevonása */
    margin-top: 20px; /* Felső margó */
    background-color: #fff; /* Fehér háttér */
}
/* Táblázat cellák stílusa */
th, td {
    padding: 10px; /* Belső margó */
    border: 1px solid #5c3a2e; /* Sötétbarna keret */
    text-align: center; /* Középre igazítás */
}

/* Táblázat fejlécek stílusa */
th {
    background-color: #5c3a2e; /* Sötétbarna háttér */
    color: white; /* Fehér szöveg */
}

/* Páros sorok háttérszíne világosabb */
tr:nth-child(even) {
    background-color: #f8f8f8;
}

/* Gombok és vissza link stílusa */
button, .vissza-link {
    padding: 10px 20px; /* Belső margó */
    background-color: #5c3a2e; /* Barna háttér */
    color: white; /* Fehér szöveg */
    border: none; /* Nincs keret */
    border-radius: 5px; /* Lekerekített sarkok */
    font-weight: bold;
    cursor: pointer; /* Mutató kéz */
    text-decoration: none; /* Link aláhúzás nélkül */
}

/* Hover állapot gombokon és linkeken */
button:hover, .vissza-link:hover {
    background-color: #3e251b; /* Sötétebb barna */
}

/* Vissza link speciális stílusa */
.vissza-link {
    display: inline-block;
    margin-top: 20px;
    text-align: center;
}
</style>
</head>
<body>
<!-- Oldal logója -->
<div class="logo-box">Fabolcs</div>

<!-- Üzenetek megjelenítő doboz -->
<div class="modal-box">
    <h2>Beérkezett üzenetek</h2>

    <!-- Ha nincs üzenet -->
    <?php if (empty($uzenetek)): ?>
        <p>Nincs egyedi üzenet.</p>
    <?php else: ?>
        <!-- Üzenetek táblázatos megjelenítése űrlappal -->
        <form method="post">
            <table>
                <tr>
                    <th>Név</th>
                    <th>Email</th>
                    <th>Telefonszám</th>
                    <th>Üzenet</th>
                    <th>Dátum</th>
                    <th>Olvasott</th>
                    <th>Válaszolt</th>
                </tr>
                <?php foreach ($uzenetek as $uzenet): ?>
                    <tr>
                        <td><?= htmlspecialchars($uzenet['nev']) ?></td> <!-- Küldő neve -->
                        <td><?= htmlspecialchars($uzenet['email']) ?></td> <!-- Email cím -->
                        <td><?= htmlspecialchars($uzenet['telefon']) ?></td> <!-- Telefonszám -->
                        <td><?= nl2br(htmlspecialchars($uzenet['uzenet'])) ?></td> <!-- Üzenet szöveg -->
                        <td><?= htmlspecialchars($uzenet['datum']) ?></td> <!-- Küldés dátuma -->
                        <td><?= $uzenet['olvasott'] ? '✔️' : 'Új' ?></td> <!-- Olvasottság jelzése -->
                        <td>
                            <!-- Checkbox a válaszolt állapot jelzésére -->
                            <input type="checkbox" name="valaszolt_ids[]" value="<?= $uzenet['id'] ?>" <?= $uzenet['valaszolt'] ? 'checked' : '' ?>>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
            <!-- Válaszolt státusz mentése -->
            <button type="submit">Válaszolás mentése</button>
        </form>
    <?php endif; ?>

    <!-- Vissza a főoldalra -->
    <a href="index.php" class="vissza-link">← Vissza a főoldalra</a>
</div>
</body>
</html>