<?php
// MINDEN PHP oldal elején session indítás a felhasználói állapot (pl. kosár) megőrzéséhez
session_start();

// Adatbáziskapcsolat behúzása
require_once 'adatbazis.php';

// Termékek tömb a kosár tartalmához
$termekek = [];

// Kosár végösszeg inicializálása
$vegosszeg = 0;

// Bejelentkezett-e a felhasználó?
$bejelentkezett = isset($_SESSION['felhasznalo_id']);
$felhasznalo_id = $_SESSION['felhasznalo_id'] ?? null;

// ----------- POST KÉRÉSEK KEZELÉSE -----------

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Megjegyzés mentése SESSION-be
    if (isset($_POST['rendeles_megjegyzes'])) {
        $_SESSION['rendeles_megjegyzes'] = trim($_POST['rendeles_megjegyzes']);
    }

    // Termék törlése a kosárból
    if (isset($_POST['torles_id'])) {
        $torlendo_id = (int)$_POST['torles_id'];

        if ($bejelentkezett) {
            // Bejelentkezett felhasználó kosarából adatbázisban töröljük
            $stmt = $adatbazis->prepare("DELETE FROM kosar_tetelek WHERE felhasznalo_id = ? AND termek_id = ?");
            $stmt->bind_param("ii", $felhasznalo_id, $torlendo_id);
            $stmt->execute();
            $stmt->close();
        } else {
            // Vendég kosár SESSION-ből
            unset($_SESSION['kosar'][$torlendo_id]);
        }

        // Frissítés
        header("Location: kosar.php");
        exit();
    }

    // Mennyiségek frissítése
    if (isset($_POST['uj_mennyiseg'])) {
        foreach ($_POST['uj_mennyiseg'] as $termek_id => $mennyiseg) {
            $mennyiseg = max(0, (int)$mennyiseg);

            if ($bejelentkezett) {
                if ($mennyiseg > 0) {
                    // Frissítjük az adatbázisban
                    $stmt = $adatbazis->prepare("UPDATE kosar_tetelek SET mennyiseg = ? WHERE felhasznalo_id = ? AND termek_id = ?");
                    $stmt->bind_param("iii", $mennyiseg, $felhasznalo_id, $termek_id);
                    $stmt->execute();
                    $stmt->close();
                } else {
                    // Törlés ha 0
                    $stmt = $adatbazis->prepare("DELETE FROM kosar_tetelek WHERE felhasznalo_id = ? AND termek_id = ?");
                    $stmt->bind_param("ii", $felhasznalo_id, $termek_id);
                    $stmt->execute();
                    $stmt->close();
                }
            } else {
                // Vendég kosár SESSION-ben
                if ($mennyiseg > 0) {
                    $_SESSION['kosar'][$termek_id] = $mennyiseg;
                } else {
                    unset($_SESSION['kosar'][$termek_id]);
                }
            }
        }

        // Frissítés
        header("Location: kosar.php");
        exit();
    }
}

// ----------- KOSÁR BETÖLTÉSE -----------

if ($bejelentkezett) {
    // Bejelentkezett felhasználó kosarának lekérdezése adatbázisból
    $stmt = $adatbazis->prepare("
        SELECT t.id, t.nev, t.ar, k.mennyiseg 
        FROM kosar_tetelek k 
        INNER JOIN termekek t ON k.termek_id = t.id 
        WHERE k.felhasznalo_id = ?
    ");
    $stmt->bind_param("i", $felhasznalo_id);
    $stmt->execute();
    $eredmeny = $stmt->get_result();

    while ($sor = $eredmeny->fetch_assoc()) {
        $sor['reszosszeg'] = $sor['ar'] * $sor['mennyiseg'];
        $vegosszeg += $sor['reszosszeg'];
        $termekek[] = $sor;
    }

    $stmt->close();

} elseif (!empty($_SESSION['kosar'])) {
    // Vendég felhasználó kosara SESSION-ből
    $kosar = $_SESSION['kosar'];
    $ids = implode(",", array_map("intval", array_keys($kosar)));

    $sql = "SELECT * FROM termekek WHERE id IN ($ids)";
    $eredmeny = $adatbazis->query($sql);

    while ($sor = $eredmeny->fetch_assoc()) {
        $termek_id = $sor['id'];
        $mennyiseg = $kosar[$termek_id];
        $sor['mennyiseg'] = $mennyiseg;
        $sor['reszosszeg'] = $mennyiseg * $sor['ar'];
        $vegosszeg += $sor['reszosszeg'];
        $termekek[] = $sor;
    }
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
<meta charset="UTF-8">
<title>Kosár</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
/* -------- EGYEDI BETŰTÍPUS -------- */
@font-face {
    font-family: 'Distant Stroke';
    src: url('fonts/Distant_Stroke.otf') format('opentype');
    font-weight: normal;
    font-style: normal;
}

/* -------- ALAP BODY STÍLUS -------- */
body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
    display: flex;
    flex-direction: column;
    align-items: center;
    background-color: #4b2e1e;        /* Barna háttérszín */
    position: relative;
    min-height: 100vh;
}

/* -------- HÁTTÉRKÉP FAEREZET MINTÁVAL -------- */
body::after {
    content: "";
    position: fixed;
    top: 0; left: 0;
    width: 100%; height: 100%;
    background: url('kepek/erezet2.jpg') repeat;
    z-index: -1;                       /* A tartalom mögé kerül */
}

/* -------- FENTI LOGO-BOX -------- */
.logo-box {
    background: #5c3a2e;               /* Sötétbarna háttér */
    border-radius: 12px;               /* Lekerekített sarkok */
    padding: 10px 30px;                /* Belső margó */
    margin: 30px auto 10px;            /* Felső és alsó margó középre igazítva */
    max-width: 720px;                  /* Max szélesség nagy képernyőn */
    width: 95%;                        /* Reszponzív szélesség */
    text-align: center;
    font-family: 'Distant Stroke', sans-serif; /* Egyedi betűtípus */
    font-size: 80px;                   /* Nagy betűméret */
    color: #ffffff;                    /* Fehér szöveg */
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2); /* Árnyék */
}

/* -------- MODAL-BOX KONTÉNER -------- */
.modal-box {
    background: #f5f5dc;               /* Bézs háttérszín */
    border-radius: 12px;
    padding: 30px;
    max-width: 800px;                  /* Szélesebb mint a logo-box */
    width: 95%;                        /* Mobilbarát szélesség */
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
    overflow-x: auto;                  /* Ha túl széles a tartalom, görgethető legyen */
}

/* -------- CÍMEK KÖZÉPRE -------- */
h2, h1 {
    text-align: center;
}

/* -------- TÁBLÁZAT ALAP STÍLUS -------- */
table {
    width: 100%;                       /* Teljes szélesség kitöltése */
    border-collapse: collapse;         /* Szegélyek összeolvadnak */
    margin-top: 20px;                  /* Fent margó a környező elemekhez képest */
}
/* -------- TÁBLÁZAT CELLÁK STÍLUSA -------- */
th, td {
    padding: 10px;                    /* Belső margó a szöveg körül */
    border: 1px solid #ccc;           /* Világosszürke szegély */
    text-align: center;               /* Szöveg középre igazítása */
    background-color: white;          /* Fehér háttér */
}

/* -------- DARABSZÁM BEVITELI MEZŐ -------- */
input[type="number"] {
    width: 60px;                      /* Fix szélesség */
    text-align: center;               /* A szám középen jelenik meg */
    padding: 5px;                     /* Belső margó */
    border-radius: 5px;               /* Lekerekített sarkok */
    border: 1px solid #ccc;           /* Világosszürke szegély */
}

/* -------- KOSÁR NAVIGÁCIÓ GOMBOK KONTAINER -------- */
.kosar-navigacio {
    display: flex;                    /* Flexbox elrendezés */
    gap: 10px;                        /* Gombok közötti hézag */
    justify-content: center;          /* Középre igazítva vízszintesen */
    margin-top: 20px;                 /* Felső margó a táblázattól */
    flex-wrap: wrap;                  /* Több sorba törhető mobilon */
}

/* -------- NAVIGÁCIÓ GOMBOK, LINKEK ALAP STÍLUS -------- */
.kosar-navigacio button,
.kosar-navigacio a,
.kosar-vissza-link {
    padding: 10px 20px;               /* Kényelmes kattintható terület */
    background-color: #5c3a2e;        /* Sötétbarna háttérszín */
    color: white;                     /* Fehér szöveg */
    text-decoration: none;            /* Linkek aláhúzását eltávolítja */
    border-radius: 5px;               /* Lekerekített sarkok */
    font-weight: bold;
    border: 2px solid #5c3a2e;        /* Kiemelt barna szegély */
    transition: background-color 0.3s, color 0.3s; /* Sima színváltás hoverkor */
    cursor: pointer;
}

/* -------- HOVER EFFEKT A GOMBOKRA ÉS LINKEKRE -------- */
.kosar-navigacio button:hover,
.kosar-navigacio a:hover,
.kosar-vissza-link:hover {
    background-color: #f5f5dc;        /* Világos bézs háttér hoverkor */
    color: #5c3a2e;                    /* Barna szöveg hoverkor */
}
</style>
</head>
<body>

<!-- ---------- Fő oldali logó felirat doboz ---------- -->
<div class="logo-box">Fabolcs</div>

<!-- ---------- Kosár tartalmát megjelenítő modál-doboz ---------- -->
<div class="modal-box">

    <!-- ---------- Bejelentkezési státusz sáv ---------- -->
    <div class="status">
        <?php if ($bejelentkezett): ?>
            <!-- Ha be van jelentkezve, kiírja az email címét -->
            <p>Bejelentkezve mint: <strong><?= htmlspecialchars($_SESSION['felhasznalo_email']) ?></strong></p>
        <?php else: ?>
            <!-- Ha nem, akkor bejelentkezési linket ad -->
            <a href="bejelentkezes.php">Bejelentkezés</a>
        <?php endif; ?>
    </div>

    <!-- ---------- Kosár cím fejléc ---------- -->
    <h1>Kosár tartalma</h1>

    <?php if (empty($termekek)): ?>
        <!-- Ha a kosár üres -->
        <p style="text-align: center;">A kosár üres.</p>
        <p style="text-align: center;">
            <a href="index.php" class="kosar-vissza-link">← Vissza a főoldalra</a>
        </p>
    <?php else: ?>
        <!-- ---------- Ha van termék a kosárban ---------- -->
        <form method="post">
            <table>
                <thead>
                    <tr>
                        <th>Termék</th>
                        <th>Egységár</th>
                        <th>Darabszám</th>
                        <th>Részösszeg</th>
                        <th>Művelet</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($termekek as $termek): ?>
                        <tr>
                            <!-- Termék neve -->
                            <td><?= htmlspecialchars($termek['nev']) ?></td>
                            <!-- Termék ára -->
                            <td><?= $termek['ar'] ?> Ft</td>
                            <!-- Mennyiség módosítható input -->
                            <td>
                                <input type="number" name="uj_mennyiseg[<?= $termek['id'] ?>]" value="<?= $termek['mennyiseg'] ?>" min="0">
                            </td>
                            <!-- Részösszeg -->
                            <td><?= $termek['reszosszeg'] ?> Ft</td>
                            <!-- Törlés gomb -->
                            <td>
                                <button type="submit" name="torles_id" value="<?= $termek['id'] ?>" style="background: none; border: none; color: black; font-size: 18px;">❌</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- ---------- Megjegyzés a rendeléshez szövegdoboz ---------- -->
            <div class="section">
                <label for="rendeles_megjegyzes"><strong>Megjegyzés a rendeléshez:</strong></label><br>
                <textarea id="rendeles_megjegyzes" name="rendeles_megjegyzes" rows="4" style="width: 100%; border-radius: 5px; padding: 8px; border: 1px solid #ccc;">
                    <?= htmlspecialchars($_SESSION['rendeles_megjegyzes'] ?? '') ?>
                </textarea>
            </div>

            <!-- ---------- Navigációs gombok a kosár alján ---------- -->
            <div class="kosar-navigacio">
                <a href="index.php">← Vissza a főoldalra</a>
                <button type="submit" formaction="szallitas_cim.php">Tovább a szállításhoz →</button>
            </div>
        </form>
    <?php endif; ?>

</div>
<script>
document.querySelectorAll('input[type="number"]').forEach(input => {
    input.addEventListener('change', function () {
        const termekId = this.name.match(/\d+/)[0];
        const mennyiseg = this.value;

        fetch('kosar_frissit.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `termek_id=${termekId}&mennyiseg=${mennyiseg}`
        })
        .then(response => response.json())
        .then(data => {
            // Részösszeg frissítése
            const reszosszegTd = this.closest('tr').querySelector('td:nth-child(4)');
            reszosszegTd.textContent = data.reszosszeg + ' Ft';

            // Végösszeg frissítése
            document.getElementById('vegosszeg-mezo').textContent = data.vegosszeg + ' Ft';
        });
    });
});
</script>
</body>
</html>