<?php
// Minden session-használathoz kötelező: indítjuk a session-t.
// Itt arra van szükség, hogy hozzáférjünk és törölhessük a meglévő session-adatokat.
session_start();

// A session minden adatát törli, és érvényteleníti a session ID-t a szerveren.
// Ez az, ami kijelentkezést csinál – minden felhasználói adat elfelejtődik.
session_destroy();

// A felhasználót átirányítjuk a főoldalra (index.php), hogy ne maradjon ezen az oldalon.
// Így egyből "vendégként" láthatja a főoldalt a kijelentkezés után.
header("Location: index.php");

// Biztonságból megszakítjuk a script futását, hogy semmi más ne történjen.
exit();
?>