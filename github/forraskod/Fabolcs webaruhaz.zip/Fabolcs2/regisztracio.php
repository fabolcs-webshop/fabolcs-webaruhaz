<?php
// Adatbáziskapcsolatot behúzzuk
require_once 'adatbazis.php';

// Válaszobjektum előkészítése a visszaküldéshez (JSON)
$response = ['hiba' => '', 'siker' => false];

// Ellenőrizzük, hogy POST metódussal jött-e kérés
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Felhasználó által beküldött adatok tisztítása és mentése változókba
    $nev     = trim($_POST['nev'] ?? '');
    $telefon = trim($_POST['telefon'] ?? '');
    $email   = strtolower(trim($_POST['email'] ?? ''));
    $jelszo  = $_POST['jelszo'] ?? '';
    $jelszo2 = $_POST['jelszo2'] ?? '';

    // Regexp minták ellenőrzéshez
    $nev_regex     = '/^(?! )[a-zA-ZáéíóöőúüűÁÉÍÓÖŐÚÜŰ]+(?: [a-zA-ZáéíóöőúüűÁÉÍÓÖŐÚÜŰ]+){0,2}$/u';
    $telefon_regex = '/^\+?[0-9\s\-]{7,20}$/';
    $email_regex   = '/^[a-zA-Z0-9._-]{1,12}@[a-z]{1,12}\.(hu|com)$/';
    $jelszo_regex  = '/^[a-zA-Z0-9]{1,12}$/';

    // ✅ Üres mező ellenőrzés
    if ($nev === '' || $telefon === '' || $email === '' || $jelszo === '' || $jelszo2 === '') {
        $response['hiba'] = 'Minden mezőt ki kell tölteni!';

    // ✅ Név ellenőrzés
    } elseif (!preg_match($nev_regex, $nev)) {
        $response['hiba'] = 'A név formátuma nem megfelelő!';

    // ✅ Telefonszám ellenőrzés
    } elseif (!preg_match($telefon_regex, $telefon)) {
        $response['hiba'] = 'A telefonszám formátuma nem megfelelő!';

    // ✅ Email ellenőrzés
    } elseif (!preg_match($email_regex, $email)) {
        $response['hiba'] = 'Az e-mail formátuma nem megfelelő!';

    // ✅ Jelszó formátum ellenőrzés
    } elseif (!preg_match($jelszo_regex, $jelszo)) {
        $response['hiba'] = 'A jelszó nem megfelelő!';

    // ✅ Kétszeri jelszó egyezés
    } elseif ($jelszo !== $jelszo2) {
        $response['hiba'] = 'A két jelszó nem egyezik!';

    } else {
        // Ellenőrizzük, van-e már ilyen e-mail
        $ellenor = $adatbazis->prepare("SELECT id FROM felhasznalok WHERE email = ?");
        $ellenor->bind_param("s", $email);
        $ellenor->execute();
        $ellenor->store_result();

        if ($ellenor->num_rows > 0) {
            // Ha már regisztrálták
            $response['hiba'] = 'Ez az e-mail cím már regisztrálva van.';

        } else {
            // ✅ Minden OK → Jelszó titkosítása
            $hash = password_hash($jelszo, PASSWORD_DEFAULT);

            // Új felhasználó beszúrása az adatbázisba
            $beszuras = $adatbazis->prepare(
                "INSERT INTO felhasznalok (nev, telefon, email, jelszo) VALUES (?, ?, ?, ?)"
            );
            $beszuras->bind_param("ssss", $nev, $telefon, $email, $hash);

            if ($beszuras->execute()) {
                $response['siker'] = true;
            } else {
                $response['hiba'] = 'Hiba történt a mentéskor.';
            }

            $beszuras->close();
        }

        $ellenor->close();
    }

    // JSON formában visszaküldjük a választ
    echo json_encode($response);
    exit;
}
?>

<!-- --------------- REGISZTRÁCIÓS ŰRLAP HTML --------------- -->
<h2 style="text-align: center;">Regisztráció</h2>

<form id="regForm">
    <label>
        Név:<br>
        <input type="text" name="nev" required>
    </label><br><br>

    <label>
        Telefonszám:<br>
        <input type="text" name="telefon" required>
    </label><br><br>

    <label>
        E-mail:<br>
        <input type="email" name="email" required>
    </label><br><br>

    <label>
        Jelszó:<br>
        <input type="password" name="jelszo" required>
    </label><br><br>

    <label>
        Jelszó újra:<br>
        <input type="password" name="jelszo2" required>
    </label><br><br>

    <button type="submit">Regisztráció</button>

    <div id="regValasz" style="margin-top: 10px; color: red;"></div>
</form>
