<?php
session_start();
require_once 'adatbazis.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['siker' => false, 'hiba' => 'Érvénytelen kérés']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

$felhasznalo_id = $_SESSION['felhasznalo_id'] ?? null;
$uzenet = $data['uzenet'] ?? '';

if (!$felhasznalo_id || !$uzenet) {
    echo json_encode(['siker' => false, 'hiba' => 'Hiányzó adatok']);
    exit;
}

// 🔥 Itt kérdezzük le a felhasználó saját email címét
$stmt = $adatbazis->prepare("SELECT email FROM felhasznalok WHERE id = ?");
$stmt->bind_param("i", $felhasznalo_id);
$stmt->execute();
$stmt->bind_result($email);
$stmt->fetch();
$stmt->close();

if (!$email) {
    echo json_encode(['siker' => false, 'hiba' => 'Felhasználó email nem található']);
    exit;
}

$nev = 'Automata üzenet';
$telefon = ''; // nincs telefonszám

// ✅ Az emailt már a felhasználóé!
$stmt = $adatbazis->prepare("INSERT INTO egyedi_keresek (nev, email, telefon, uzenet, olvasott) VALUES (?, ?, ?, ?, 0)");
$stmt->bind_param("ssss", $nev, $email, $telefon, $uzenet);

if ($stmt->execute()) {
    echo json_encode(['siker' => true]);
} else {
    echo json_encode(['siker' => false, 'hiba' => 'Mentési hiba']);
}

$stmt->close();
?>