<?php
session_start();
require_once 'adatbazis.php';

// Csak admin módosíthatja az adatokat: ellenőrizzük, hogy be van-e jelentkezve, és admin-e
if (!isset($_SESSION['felhasznalo_id']) || $_SESSION['admin'] != 1) {
    // Ha nem admin, átirányítás a főoldalra és kilépés
    header("Location: index.php");
    exit();
}

// Csak POST kérés esetén hajtjuk végre a státusz frissítést
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // POST-ból lekérjük a rendelés azonosítóját és az új státuszt
    $rendeles_id = $_POST['rendeles_id'];
    $statusz = $_POST['statusz'];

    // Előkészítjük az SQL frissítő lekérdezést, hogy módosítsuk a rendelés státuszát
    $stmt = $adatbazis->prepare("UPDATE uj_rendelesek SET statusz = ? WHERE id = ?");
    $stmt->bind_param("si", $statusz, $rendeles_id);
    $stmt->execute();
    $stmt->close();
}

// Frissítés után visszairányítjuk az admin oldalra
header("Location: admin.php");
exit();
