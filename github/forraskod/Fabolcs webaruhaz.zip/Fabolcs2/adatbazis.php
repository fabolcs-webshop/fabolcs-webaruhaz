<?php
// Automatikus betöltés: ha létezik adatbazis_xampp.php, akkor azt töltjük be
if (file_exists('adatbazis_xampp.php')) {
    require_once 'adatbazis_xampp.php';
// Ellenkező esetben, ha létezik adatbazis_wamp.php, akkor azt töltjük be
} elseif (file_exists('adatbazis_wamp.php')) {
    require_once 'adatbazis_wamp.php';
// Ha egyik sem található, hibaüzenettel leállunk
} else {
    die("Nem található megfelelő adatbázis konfiguráció.");
}
?>