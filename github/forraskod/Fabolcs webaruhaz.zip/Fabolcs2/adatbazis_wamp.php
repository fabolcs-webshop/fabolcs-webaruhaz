<?php
// WAMP környezethez készült adatbázis kapcsolódás

// Kapcsolódás a MySQL adatbázishoz: host, felhasználó, jelszó, adatbázis neve
$adatbazis = new mysqli("localhost", "root", "", "fabolcs_webaruhaz");

// Ha a kapcsolat nem jön létre, kilépünk és kiírjuk a hibát
if ($adatbazis->connect_error) {
    die("Adatbázis kapcsolódási hiba (WAMP): " . $adatbazis->connect_error);
}

// Beállítjuk az adatbázis kapcsolat karakterkódolását UTF-8-ra, hogy ékezetes karakterek helyesen jelenjenek meg
$adatbazis->set_charset("utf8");
?>