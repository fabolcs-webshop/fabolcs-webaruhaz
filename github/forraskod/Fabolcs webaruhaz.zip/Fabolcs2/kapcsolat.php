<?php
session_start();
require_once 'adatbazis.php';

$uzenet = ''; // Visszajelző üzenet siker esetén
$hiba = '';   // Hibajelzés változó, ha valami nem stimmel

if ($_SERVER["REQUEST_METHOD"] === "POST") { // Csak POST kérések esetén dolgozunk
    // Űrlapmezők értékeinek lekérése, levágva a felesleges szóközöket
    $nev = trim($_POST['nev'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $telefon = trim($_POST['telefon'] ?? '');
    $uzenet_szoveg = trim($_POST['uzenet'] ?? '');

    // Alap ellenőrzések: nincs üres mező
    if ($nev === '' || $email === '' || $telefon === '' || $uzenet_szoveg === '') {
        $hiba = "Minden mező kitöltése kötelező!";
    }
    // Név formátum ellenőrzése: csak betűk, szóköz, kötőjel, legalább 3 karakter
    elseif (!preg_match('/^[a-zA-ZáéíóöőúüűÁÉÍÓÖŐÚÜŰ\s-]{3,}$/u', $nev)) {
        $hiba = "A név csak betűket, szóközt és kötőjelet tartalmazhat, minimum 3 karakterrel.";
    }
    // Email formátum validálása PHP filterrel és regex-szel, dupla ellenőrzés
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match('/^[^@]+@[^@]+\.[^@]+$/', $email)) {
        $hiba = "Érvénytelen email cím formátum!";
    }
    // Telefonszám formátuma: számok, szóköz, pluszjel, zárójel, kötőjel, legalább 6 karakter
    elseif (!preg_match('/^[0-9+\s()-]{6,}$/', $telefon)) {
        $hiba = "A telefonszám csak számokat, szóközt, + jelet, zárójelet és kötőjelet tartalmazhat, minimum 6 karakterrel.";
    }
    // Üzenet tartalmának ellenőrzése: engedélyezett karakterek, legalább 3 karakter
    elseif (!preg_match('/^[a-zA-Z0-9áéíóöőúüűÁÉÍÓÖŐÚÜŰ\s.,!"\'-]{3,}$/u', $uzenet_szoveg)) {
        $hiba = "Az üzenet csak betűket, számokat, pontot, vesszőt, felkiáltójelet, idézőjelet, kötőjelet és szóközt tartalmazhat, minimum 3 karakterrel.";
    }
    else {
        // Ha minden rendben, az üzenet adatbázisba mentése előkészítve
        $stmt = $adatbazis->prepare("INSERT INTO egyedi_keresek (nev, email, telefon, uzenet) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $nev, $email, $telefon, $uzenet_szoveg);
        if ($stmt->execute()) {
            // Sikeres mentés esetén visszajelzés
            $uzenet = "Köszönjük! Az üzenetet sikeresen elküldte. Hamarosan felvesszük Önnel a kapcsolatot.";
        } else {
            // Hibakezelés ha az adatbázis mentés nem sikerül
            $hiba = "Hiba történt az üzenet mentésekor.";
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
<meta charset="UTF-8">
<title>Kapcsolat</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>
/* Egyedi betűtípus betöltése */
@font-face {
    font-family: 'Distant Stroke';
    src: url('fonts/Distant_Stroke.otf') format('opentype');
    font-weight: normal;
    font-style: normal;
}

/* Alap body stílusok */
body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
    background-color: #4b2e1e;  /* Sötétbarna háttér */
    position: relative;
    min-height: 100vh;          /* Legalább a képernyő magassága */
}

/* Háttérképet faerezet mintával ismételve */
body::after {
    content: "";
    position: fixed;
    top: 0; left: 0;
    width: 100%; height: 100%;
    background: url('kepek/erezet2.jpg') repeat;
    z-index: -1;                /* Háttér mögé helyezzük */
}

/* Nagy logó box */
.logo-box {
    background: #5c3a2e;         /* Sötétbarna háttér */
    border-radius: 12px;         /* Lekerekített sarkok */
    padding: 10px 30px;
    margin: 30px auto 10px;
    max-width: 720px;
    width: 95%;
    text-align: center;          /* Középre igazítás */
    font-family: 'Distant Stroke', sans-serif;
    font-size: 80px;
    color: #ffffff;              /* Fehér szöveg */
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2); /* Finom árnyék */
}

/* Tartalom doboz stílusa */
.modal-box {
    background: #f5f5dc;         /* Bézs háttér */
    border-radius: 12px;
    padding: 30px;
    max-width: 720px;
    width: 95%;
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
    margin: 20px auto;
}

/* Cím középre igazítása és margin */
.modal-box h2 {
    text-align: center;
    margin-top: 0;
}

/* Beállítások a bekezdések és elérhetőség osztályhoz */
.modal-box p, .modal-box .elérhetőség {
    margin: 10px 0 20px;
    text-align: center;
    font-weight: bold;           /* Félkövér szöveg */
    color: #5c3a2e;              /* Sötétbarna szín */
    white-space: pre-line;       /* Sortörések megtartása */
}
/* A form elemek alapértelmezett stílusai: függőleges elrendezés, elemek közti térköz */
form {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

/* Label címkék vastag betűvel és barna színnel */
label {
    font-weight: bold;
    color: #5c3a2e;
}

/* Szövegbeviteli mezők, e-mail, telefon és textarea stílusai */
input[type="text"], input[type="email"], input[type="tel"], textarea {
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #ccc;
    width: 100%;            /* Teljes szélesség */
    box-sizing: border-box; /* A padding is beleszámít a szélességbe */
}

/* Textarea minimális magassága és méretezhetősége */
textarea {
    min-height: 120px;
    resize: vertical;       /* Függőlegesen méretezhető */
}

/* Gombok és vissza-link konténerének stílusa: középre rendezett, függőleges elemekkel */
.gomb-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 10px;
    margin-top: 20px;
}

/* Gombok és visszalépő linkek stílusai */
button, .vissza-link {
    padding: 12px 30px;
    background-color: #5c3a2e;   /* Sötétbarna háttér */
    color: white;                /* Fehér szöveg */
    border: none;
    border-radius: 5px;
    font-weight: bold;
    cursor: pointer;
    text-decoration: none;       /* Linkek aláhúzásának kikapcsolása */
    text-align: center;
    display: inline-block;
    width: 80%;
    max-width: 300px;            /* Maximum szélesség */
}

/* Hover effekt a gombokra és linkekre: sötétebb barna */
button:hover, .vissza-link:hover {
    background-color: #3e251b;
}

/* Sikeres üzenet megjelenítési stílus: zöld, középre igazított */
.success-message {
    color: green;
    text-align: center;
    margin-top: 10px;
}

/* Hibaüzenet megjelenítési stílus: piros, középre igazított */
.error-message {
    color: red;
    text-align: center;
    margin-top: 10px;
}
</style>
</head>
<body>
<!-- Webáruház logója -->
<div class="logo-box">Fabolcs</div>

<!-- Fő tartalom doboz -->
<div class="modal-box">
    <h2>Kapcsolat</h2>
    <!-- Elérhetőségek megjelenítése előre megadott szövegként -->
    <p class="elérhetőség">Elérhetőség
Telefon: +36305671147
E-mail: fabolcs@gmail.com</p>

    <!-- Sikeres üzenet esetén megjelenő zöld üzenet -->
    <?php if ($uzenet): ?>
        <div class="success-message"><?= htmlspecialchars($uzenet) ?></div>
    <!-- Hiba esetén piros színű hibaüzenet -->
    <?php elseif ($hiba): ?>
        <div class="error-message"><?= htmlspecialchars($hiba) ?></div>
    <?php endif; ?>

    <!-- Üzenetküldő űrlap -->
    <form method="post" action="">
        <label for="nev">Név:<br>
            <!-- Kötelezően kitöltendő név mező -->
            <input type="text" id="nev" name="nev" required placeholder="Kötelező a kitöltése...">
        </label>

        <label for="email">Email cím:<br>
            <!-- Kötelezően kitöltendő e-mail mező -->
            <input type="email" id="email" name="email" required placeholder="Kötelező a kitöltése...">
        </label>

        <label for="telefon">Telefonszám:<br>
            <!-- Kötelező telefonszám mező -->
            <input type="tel" id="telefon" name="telefon" required placeholder="Kötelező a kitöltése...">
        </label>

        <label for="uzenet">Üzenet:<br>
            <!-- Kötelező üzenet mező, textarea -->
            <textarea id="uzenet" name="uzenet" required placeholder="Üzenet..."></textarea>
        </label>

        <!-- Gombok konténer -->
        <div class="gomb-container">
            <!-- Üzenetküldő gomb -->
            <button type="submit">Küldés</button>
            <!-- Vissza a főoldalra link, gombként formázva -->
            <a href="index.php" class="vissza-link">← Vissza a főoldalra</a>
        </div>
    </form>
</div>
</body>
</html>