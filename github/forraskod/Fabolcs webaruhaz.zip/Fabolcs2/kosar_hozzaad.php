<?php
// --- SESSION indítása ---
// A felhasználói állapot (pl. bejelentkezés, kosár) nyomon követéséhez
session_start();

// --- Adatbázis kapcsolat behúzása ---
require_once 'adatbazis.php';

// --- Termék ID és darabszám bekérése űrlapról ---
// Alapértelmezett értékek, ha hiányoznak
$termek_id = (int)($_POST['termek_id'] ?? 0);
$mennyiseg = max(1, (int)($_POST['mennyiseg'] ?? 1)); // Minimum 1 darab

// --- Ha hibás a termék ID, visszadobjuk a főoldalra ---
if ($termek_id <= 0) {
    header("Location: index.php");
    exit();
}

// --- Felhasználó be van-e jelentkezve? ---
if (isset($_SESSION['felhasznalo_id'])) {
    // ✅ BEJELENTKEZETT felhasználó esetén az adatbázisba mentjük

    $felhasznalo_id = $_SESSION['felhasznalo_id'];

    // Megnézzük, már van-e ilyen termék a kosarában
    $leker = $adatbazis->prepare("
        SELECT id, mennyiseg 
        FROM kosar_tetelek 
        WHERE felhasznalo_id = ? AND termek_id = ?
    ");
    $leker->bind_param("ii", $felhasznalo_id, $termek_id);
    $leker->execute();
    $leker->store_result();

    if ($leker->num_rows > 0) {
        // Ha már van ilyen sor, frissítjük a mennyiséget
        $leker->bind_result($sor_id, $regi_mennyiseg);
        $leker->fetch();
        $leker->close();

        $uj_mennyiseg = $regi_mennyiseg + $mennyiseg;

        $update = $adatbazis->prepare("
            UPDATE kosar_tetelek 
            SET mennyiseg = ? 
            WHERE id = ?
        ");
        $update->bind_param("ii", $uj_mennyiseg, $sor_id);
        $update->execute();
        $update->close();
    } else {
        // Ha még nincs ilyen termék a kosárban, beszúrjuk
        $leker->close();
        $beszur = $adatbazis->prepare("
            INSERT INTO kosar_tetelek (felhasznalo_id, termek_id, mennyiseg) 
            VALUES (?, ?, ?)
        ");
        $beszur->bind_param("iii", $felhasznalo_id, $termek_id, $mennyiseg);
        $beszur->execute();
        $beszur->close();
    }

} else {
    // ❌ NINCS bejelentkezve – SESSION-ben tároljuk a kosarat

    // Ha még nincs kosár a session-ben, inicializáljuk
    if (!isset($_SESSION['kosar'])) {
        $_SESSION['kosar'] = [];
    }

    // Meglévő termékhez hozzáadjuk a darabszámot, vagy új elem
    if (isset($_SESSION['kosar'][$termek_id])) {
        $_SESSION['kosar'][$termek_id] += $mennyiseg;
    } else {
        $_SESSION['kosar'][$termek_id] = $mennyiseg;
    }
}

// --- Visszairányítás a főoldalra (index) ---
header("Location: index.php");
exit();
