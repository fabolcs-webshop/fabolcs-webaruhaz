



<?php
session_start();
require_once 'adatbazis.php';

if (!isset($_SESSION['felhasznalo_id'])) {
    header("Location: bejelentkezes.php");
    exit();
}

$felhasznalo_id = $_SESSION['felhasznalo_id'];

$stmt = $adatbazis->prepare("SELECT email, regdatum FROM felhasznalok WHERE id = ?");
$stmt->bind_param("i", $felhasznalo_id);
$stmt->execute();
$stmt->bind_result($email, $regdatum);
$stmt->fetch();
$stmt->close();

$utolso_cim = 'Nincs megadva';
$stmt = $adatbazis->prepare("SELECT cim FROM szallitasi_cimek WHERE felhasznalo_id = ? ORDER BY id DESC LIMIT 1");
$stmt->bind_param("i", $felhasznalo_id);
$stmt->execute();
$stmt->bind_result($utolso_cim);
$stmt->fetch();
$stmt->close();

$rendelesek = [];
$stmt = $adatbazis->prepare("
    SELECT r.id, r.rendeles_azonosito, r.datum, r.statusz, sp.nev AS szallitas_nev, sp.ar AS szallitas_ar
    FROM uj_rendelesek r
    JOIN szallitasi_partnerek sp ON r.szallitasi_partner_id = sp.id
    WHERE r.felhasznalo_id = ?
    ORDER BY r.datum DESC
");
$stmt->bind_param("i", $felhasznalo_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $rendeles_id = $row['id'];
    $row['termekek'] = [];
    $vegosszeg = $row['szallitas_ar'];

    $stmt2 = $adatbazis->prepare("
        SELECT t.nev, rt.mennyiseg, t.ar
        FROM rendeles_tetelek rt
        JOIN termekek t ON rt.termek_id = t.id
        WHERE rt.rendeles_id = ?
    ");
    $stmt2->bind_param("i", $rendeles_id);
    $stmt2->execute();
    $res2 = $stmt2->get_result();
    while ($sor2 = $res2->fetch_assoc()) {
        $row['termekek'][] = $sor2;
        $vegosszeg += $sor2['mennyiseg'] * $sor2['ar'];
    }
    $stmt2->close();

    $row['vegosszeg'] = $vegosszeg;
    $row['cim'] = $utolso_cim;
    $rendelesek[] = $row;
}
$stmt->close();
?>
<!DOCTYPE html>
<html lang="hu">
<head>
<meta charset="UTF-8">
<title>Fiókom</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
@font-face {
    font-family: 'Distant Stroke';
    src: url('fonts/Distant_Stroke.otf') format('opentype');
    font-weight: normal;
    font-style: normal;
}
body {
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
    display: flex;
    flex-direction: column;
    align-items: center;
    background-color: #4b2e1e;
    position: relative;
    min-height: 100vh;
}
body::after {
    content: "";
    position: fixed;
    top: 0; left: 0;
    width: 100%; height: 100%;
    background: url('kepek/erezet2.jpg') repeat;
    z-index: -1;
}
.logo-box {
    background: #5c3a2e;
    border-radius: 12px;
    padding: 10px 30px;
    margin: 30px auto 10px;
    max-width: 720px;
    width: 95%;
    text-align: center;
    font-family: 'Distant Stroke', sans-serif;
    font-size: 80px;
    color: #ffffff;
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
}
.modal-box {
    background: #f5f5dc;
    border-radius: 12px;
    padding: 30px;
    max-width: 720px;
    width: 95%;
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.2);
    overflow-y: auto;
    max-height: 90vh;
}
.section {
    margin-bottom: 20px;
}
h2 {
    text-align: center;
}
p strong {
    color: #333;
}
button.danger {
    background-color: #dc3545;
    color: white;
    padding: 10px;
    border: none;
    border-radius: 5px;
    width: 100%;
    cursor: pointer;
}
a.vissza {
    display: inline-block;
    margin-top: 20px;
    background: #5c3a2e;
    color: white;
    padding: 10px 20px;
    text-decoration: none;
    border-radius: 6px;
    font-weight: bold;
}
a.vissza:hover {
    background-color: #3e251b;
}
.rendeles-kartya {
    margin-bottom: 15px;
    padding: 15px;
    background-color: white;
    border-radius: 8px;
    box-shadow: 0 0 8px rgba(0,0,0,0.05);
}
.status-ikonok {
    display: flex;
    gap: 15px;
    margin-top: 10px;
    opacity: 0.5;
}
.status-ikonok span {
    display: inline-block;
    padding: 6px 10px;
    border-radius: 4px;
    background-color: #ccc;
    font-size: 0.9em;
}
.status-ikonok .aktiv {
    background-color: #28a745;
    color: white;
    opacity: 1;
}
ul {
    padding-left: 20px;
}
.bankinfo {
    background-color: #fff8e1;
    padding: 10px;
    margin-top: 10px;
    border-left: 5px solid #ffa000;
}
.modal {
    display: none;
    position: fixed;
    top: 0; left: 0;
    width: 100%; height: 100%;
    background: rgba(0,0,0,0.6);
    justify-content: center;
    align-items: center;
    z-index: 9999;
}
.modal-content {
    background: #f5f5dc;
    padding: 25px;
    max-width: 400px;
    width: 90%;
    border-radius: 12px;
    box-shadow: 0 8px 30px rgba(0,0,0,0.3);
    text-align: center;
    position: relative;
}
.modal-close {
    position: absolute;
    top: 10px;
    right: 15px;
    font-size: 24px;
    cursor: pointer;
    color: #5c3a2e;
}
@media (max-width: 600px) {
    .modal-box {
        padding: 20px;
    }
}
</style>
</head>
<body>
<div class="logo-box">Fabolcs</div>
<div class="modal-box">
    <div class="section">
        <h2>Profil adatok</h2>
        <p><strong>E-mail:</strong> <?= htmlspecialchars($email) ?></p>
        <p><strong>Regisztráció dátuma:</strong> <?= htmlspecialchars($regdatum) ?></p>
    </div>

    <div class="section">
        <h2>Rendeléseim</h2>
        <?php if (empty($rendelesek)): ?>
            <p>Nincs korábbi rendelés.</p>
        <?php else: ?>
            <?php foreach ($rendelesek as $rendeles): ?>
                <div class="rendeles-kartya">
                    <p><strong>Rendelési azonosító:</strong> <?= htmlspecialchars($rendeles['rendeles_azonosito']) ?></p>
                    <p><strong>Dátum:</strong> <?= $rendeles['datum'] ?></p>
                    <p><strong>Szállítás:</strong> <?= $rendeles['szallitas_nev'] ?> (<?= $rendeles['szallitas_ar'] ?> Ft)</p>
                    <p><strong>Szállítási cím:</strong> <?= htmlspecialchars($rendeles['cim']) ?></p>
                    <p><strong>Termékek:</strong></p>
                    <ul>
                        <?php foreach ($rendeles['termekek'] as $t): ?>
                            <li><?= htmlspecialchars($t['nev']) ?> × <?= $t['mennyiseg'] ?> db</li>
                        <?php endforeach; ?>
                    </ul>
                    <p><strong>Végösszeg:</strong> <?= $rendeles['vegosszeg'] ?> Ft</p>
                    <div class="bankinfo">
                        <p><strong>Fizetési információ:</strong><br>
                        Kérem a következő számlaszámra utalja el a végösszeget, és a közleménybe az alábbi rendelési azonosítót írja bele a könnyebb beazonosítás érdekében.<br>
                        Bankszámlaszám: <strong>10700158-82104729-51100009</strong><br>
                        Közlemény: <em><?= htmlspecialchars($rendeles['rendeles_azonosito']) ?></em></p>
                    </div>
                    <?php
                    $statuszok = ['fizetve', 'gyartas', 'kiszallitas', 'kezbesitve'];
                    $aktualis_index = array_search($rendeles['statusz'], $statuszok);
                    if ($aktualis_index === false) {
                        $aktualis_index = -1;
                    }
                    ?>
                    <div class="status-ikonok">
                        <?php foreach ($statuszok as $index => $sz): ?>
                            <span class="<?= $index <= $aktualis_index ? 'aktiv' : '' ?>">
                                <?= match($sz) {
                                    'fizetve' => 'Fizetés jóváhagyva',
                                    'gyartas' => 'Rendelés gyártása',
                                    'kiszallitas' => 'Rendelés kiszállítás alatt',
                                    'kezbesitve' => 'Rendelés kézbesítve',
                                    default => ucfirst($sz)
                                } ?>
                            </span>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <div class="section">
        <h2>Fiók törlése</h2>
        <button type="button" class="danger" onclick="megnyitTorlesModalt()">Fiókom végleges törlése</button>
    </div>

    <a class="vissza" href="index.php">&#8592; Vissza a főoldalra</a>
</div>

<!-- TÖRLÉSI MODÁL -->
<div id="torlesModal" class="modal">
  <div class="modal-content">
    <span class="modal-close" onclick="zarTorlesModalt()">×</span>
    <h2>Fiók törlésének kérelme</h2>
    <p>Biztosan törölni akkarja a fiókját? Ha igen akkor küldje el kérelmét hamarosan regisztrált e-mail címére tájékoztató üzenetet fogunk küldeni.</p>
    <button id="kerelemElkuldBtn" class="danger">Kérelem elküldése</button>
  </div>
</div>

<script>
function megnyitTorlesModalt() {
    document.getElementById('torlesModal').style.display = 'flex';
}
function zarTorlesModalt() {
    document.getElementById('torlesModal').style.display = 'none';
}

document.getElementById('kerelemElkuldBtn').addEventListener('click', function() {
    fetch('auto_uzenet_kuldes.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
            uzenet: 'Fiók törlési kérelem érkezett.'
        })
    })
    .then(res => res.json())
    .then(data => {
        if(data.siker){
            alert('Kérelem sikeresen elküldve!');
            zarTorlesModalt();
        } else {
            alert('Hiba történt: ' + data.hiba);
        }
    })
    .catch(() => alert('Hiba történt az elküldés során.'));
});
</script>
</body>
</html>